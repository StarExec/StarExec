#!/usr/bin/python3.4
# Stuffed Software Synthesis (SOSY)
# Copyright (C) 2009-2015  University of Bremen
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#
# @file smt2_synthesis.py
#
# @authors Ruediger Ehlers
#          Heinz Riener
#
# @version 1.0
#
import expression_sorts_and_types
import sygus
import synthesis
import itertools
import tree_to_smt2
import time
from collections import namedtuple
import utils, sys
import code, readline, rlcompleter   # in order to spawn interactive interpreter
import smt2_utils, z3

class substitution_table:
    def __init__(self):
        self.table = []

    def __str__(self):
        s = ""
        for e in self.table:
            s = s + str(e) + '\n'
        return s

    def find(self, function, arguments):
        for e in self.table:
            if e['function'] == function and str(e['arguments']) == str(arguments):
                return e
        return None

    def find_formal(self, function, arguments):
        for e in self.table:
            if e['function'] == function and str(e['formal']) == str(arguments):
                return e
        return None

    def add(self, function, arguments, formal_args, replacement):
        self.table.append({'function':function,'arguments':arguments,'formal':formal_args,'replacement':replacement})

    def replacement_variables(self):
        return [e['replacement'] for e in self.table]

############################################################################
# functions
############################################################################

# note: inputs are over-written in the vars map, outputs are re-used
def smt2_variables_from_problem(problem,postfix,vars):
    assert isinstance(vars, dict)
    new_vars = vars.copy()
    for name in problem.variables:
        if problem.variables[name]['type'] == 'in' or not name in vars:
            new_vars[name] = smt2_utils.declare_function(name + postfix, problem.variables[name]['sort'])
    return new_vars

def smt2_eliminate_function_calls(expr, f, subst, problem, postfix = ''):
    todo = []
    todo.append(expr)
    cache = z3.AstMap(ctx=expr.ctx)
    while todo:
        n = todo[-1]
        if z3.is_var(n):
            # do nothing in case of variables
            todo.pop()
            cache[n] = n
        elif z3.is_app(n):
            visited  = True
            new_args = []
            for i in range(n.num_args()):
                arg = n.arg(i)
                if not arg in cache:
                    todo.append(arg)
                    visited = False
                else:
                    new_args.append(cache[arg])

            # if all arguments have been processed?
            if visited:
                todo.pop()
                g = n.decl()
                if z3.eq(g, f) or str(g) == str(f):
                    arg_list = [n.arg(i) for i in range(0,n.num_args())]
                    table_entry = subst.find(f, arg_list)
                    if table_entry == None:
                        sort = smt2_utils.sort_string_from_expr(n)
                        replacement = smt2_utils.declare_variable('__fun' + str(utils.id()), sort)
                        formal_args = [(a['name'] + postfix) for a in problem.variables[str(f)]['grammar'].args]
                        subst.add(f, arg_list, formal_args, replacement)
                    else:
                        replacement = table_entry['replacement']
                    new_n = replacement
                else:
                    new_n = smt2_utils.update_term(n, new_args)
                cache[n] = new_n
        else:
            assert(z3.is_quantifier(n))
            b = n.body()
            if b in cache:
                todo.pop()
                new_n = smt2_utils.update_term(n, [ cache[b] ])
                cache[n] = new_n
            else:
                todo.append(b)
    return cache[expr]

def encode_consistency(tree, vars, vars_prime, tree_map, tree_map_prime, fun_args, fun_args_prime):
    assert len(fun_args) == len(fun_args_prime)

    constraints = []
    if tree.operation == synthesis.NodeType.TUPLE:
        for child in tree.children:
            constraints = constraints + encode_consistency(child, vars, vars_prime, tree_map, tree_map_prime, fun_args, fun_args_prime)
        return constraints

    if tree.operation == synthesis.NodeType.NONE:
        if len(tree.support) > 0:
            guard = z3.And([vars[v] == vars_prime[v] for v in tree.support])
        else:
            guard = True
        key = tree.shortRepresentation()
        return [z3.Implies(guard, tree_map[key] == tree_map_prime[key])]

    if tree.operation == synthesis.NodeType.VAR or tree.operation == synthesis.NodeType.CONST:
        return []

    if tree.support == None or len(tree.support) == 0:
        return []

    # guard = z3.And([v == vp for v, vp in zip(fun_args, fun_args_prime)])
    # key = tree.shortRepresentation()
    # constraints = z3.Implies(guard, tree_map[key] == tree_map_prime[key])

    for child in tree.children:
        constraints = constraints + encode_consistency(child, vars, vars_prime, tree_map, tree_map_prime, fun_args, fun_args_prime)

    return constraints

def verify_expression(problem, tree):
    constraints = []

    ### Encode relation
    relation_variables = smt2_variables_from_problem(problem, "", dict())
    relation = smt2_utils.expr_from_string(problem.relation, relation_variables)

    ### Replace synth-fun with output variables
    subst = substitution_table()
    for fun_symbol in problem.outputs():
        relation = smt2_eliminate_function_calls(relation, relation_variables[fun_symbol], subst, problem)

    constraints.append(z3.Not(relation))

    for index, fun_symbol in enumerate(problem.outputs()):
        ### Allocate tree variables
        tree_variables = dict()

        fun_args = []
        for arg in problem.variables[fun_symbol]['grammar'].args:
            v = smt2_utils.declare_variable(arg['name'], arg['sort'])
            tree_variables[arg['name']] = v
            fun_args.append(v)

        ### Encode candidate solution tree (first time)
        tree_constraints = []; expr_map = dict(); tree_map = dict();
        results = tree_to_smt2.encode(tree, tree_variables, tree_constraints, expr_map, tree_map)
        tree_constraints.append(subst.find_formal(relation_variables[fun_symbol],[str(a) for a in fun_args])['replacement'] == results[index])
        constraints = constraints + tree_constraints

    print("[i] constraints:", constraints)

    query = z3.And(constraints)
    print('[i]', query)

    check = smt2_utils.check_sat_executable(query, 'z3', problem.query_timeout)
    if check == z3.sat:
        print ("[i] found a counterexample to concrete solution")
        return False
    elif check == z3.unknown:
        print ("[i] result of concrete solution is unknown, conservatively return false")
        return False
    elif check == z3.unsat:
        print ("[i] found a correct concrete solution")
        return True
    else:
        assert False and "Stuck with a problem"

def check_realizability(problem, tree):
    constraints = []

    ### Encode relation (first time)
    relation_variables = smt2_variables_from_problem(problem, "", dict())
    relation = smt2_utils.expr_from_string(problem.relation, relation_variables)

    ### Encode relation (second time)
    relation_variables_prime = smt2_variables_from_problem(problem, '_prime', relation_variables)
    relation_prime = smt2_utils.expr_from_string(problem.relation, relation_variables_prime)

    ### Replace synth-fun with output variables
    subst = substitution_table(); subst_prime = substitution_table()
    for fun_symbol in problem.outputs():
        relation = smt2_eliminate_function_calls(relation, relation_variables[fun_symbol], subst, problem)
        relation_prime = smt2_eliminate_function_calls(relation_prime, relation_variables_prime[fun_symbol], subst_prime, problem, "_prime")

    #print('[i] relation:',relation)
    #print('[i] relation\':',relation_prime)
    constraints.append(relation)
    constraints.append(relation_prime)

    all_variables = []

    ### Store synth-fun output variables
    for e in subst.replacement_variables():
        all_variables.append(e)
    for e in subst_prime.replacement_variables():
        all_variables.append(e)

    exist_variables = []
    for name in problem.variables:
        if problem.variables[name]['type'] == 'in':
            exist_variables.append(relation_variables[name])
            exist_variables.append(relation_variables_prime[name])

    #print('[debug]',tree)

    for index, fun_symbol in enumerate(problem.outputs()):
        ### Allocate tree variables
        tree_variables = dict()
        tree_variables_prime = dict()

        fun_args = []
        fun_args_prime = []
        for arg in problem.variables[fun_symbol]['grammar'].args:
            v = smt2_utils.declare_variable(arg['name'], arg['sort'])
            tree_variables[arg['name']] = v
            fun_args.append(v)

            v_prime = smt2_utils.declare_variable(arg['name'] + '_prime', arg['sort'])
            tree_variables_prime[arg['name']] = v_prime
            fun_args_prime.append(v_prime)

        ### Encode candidate solution tree (first time)
        tree_constraints = []; expr_map = dict(); tree_map = dict();
        results = tree_to_smt2.encode(tree, tree_variables, tree_constraints, expr_map, tree_map)
        tree_constraints.append(subst.find_formal(relation_variables[fun_symbol],[str(a) for a in fun_args])['replacement'] == results[index])
        print('[i] tree constraints:',tree_constraints)

        ### Encode candidate solution tree (second time
        tree_constraints_prime = []; expr_map_prime = dict(); tree_map_prime = dict();
        results_prime = tree_to_smt2.encode(tree, tree_variables_prime, tree_constraints_prime, expr_map_prime, tree_map_prime)
        tree_constraints_prime.append(subst_prime.find_formal(relation_variables_prime[fun_symbol],[str(a) for a in fun_args_prime])['replacement'] == results_prime[index])
        #print('[i] tree constraints\':',tree_constraints_prime)

        ### Consistency constraints
        consistency_constraints = encode_consistency(tree.candidateTree, tree_variables, tree_variables_prime, tree_map, tree_map_prime, fun_args, fun_args_prime)
        #print('[i] consistency constraints:', consistency_constraints)

        # substitute arguments and append
        for c in consistency_constraints + tree_constraints + tree_constraints_prime:
            new_c = c
            for i in range(0,len(problem.variables[fun_symbol]['grammar'].args)):
                f1 = tree_variables[problem.variables[fun_symbol]['grammar'].args[i]['name']]
                g1 = subst.find_formal(relation_variables[fun_symbol],[str(a) for a in fun_args])['arguments'][i]

                f2 = tree_variables_prime[problem.variables[fun_symbol]['grammar'].args[i]['name']]
                g2 = subst_prime.find_formal(relation_variables_prime[fun_symbol],[str(a) for a in fun_args_prime])['arguments'][i]

                new_c = smt2_utils.rewrite(new_c, f1, g1)
                new_c = smt2_utils.rewrite(new_c, f2, g2)
            constraints.append(new_c)

        ### Store cloud variables
        for e in expr_map:
            all_variables.append(expr_map[e])

        for e in expr_map_prime:
            all_variables.append(expr_map_prime[e])

    ### Construct final realizability check
    query = z3.Not(z3.And(constraints))
    if len(all_variables) > 0:
        query = z3.ForAll(all_variables, query)
    if len(exist_variables) > 0:
        query = z3.Exists(exist_variables, query)
    print('[i]', query)

    check = smt2_utils.check_sat_executable(query, 'z3', problem.query_timeout)
    if check == z3.sat:
        print ("[i] unrealizable, i.e., the SMT query is satisfiable")
        return False
    elif check == z3.unknown:
        print ("[i] realizable, i.e., the negated SMT query is unknown; conservatively realizable is assumed")
        return True
    elif check == z3.unsat:
        print ("[i] realizable, i.e., the negated SMT query is unsatisfiable")
        return True
    else:
        assert False and "Stuck with a problem"

############################################################################
# main
############################################################################


# =================================================
# SolutionTreeNode class
# =================================================
class ProblemSolutionTreeNode(synthesis.CandidateSolutionTreeNode):
    pass

# =================================================
# SolutionTree class
# =================================================
class ProblemSolutionTree(synthesis.CandidateSolutionTree):
    def isRealizable(self, problem):
        return check_realizability(problem, self)

    def isSolution(self, problem):
        return verify_expression(problem, self)

    def evaluateAbstractSolution(self, problem, needsEvaluation):
        # print( "=================[Calling 'evaluateAbstractSolution']===============" )
        # print( "INPUTS:  ", problem.input_signals )
        # print( "OUTPUTS: ", problem.output_signals )
        # print( "CONSTR:  ", problem.smt2_string )
        start = time.time()

        if (self.isFullyConcrete()):
            result = self.isSolution(problem)
            resultString = str(result)
        else:
            if needsEvaluation:

                # Are at least half of the variables not occurring in clouds anymore?
                cloudedVars = self.candidateTree.getVariablesInClouds()
                allVars = set([])
                for a in self.candidateTree.children:
                    allVars |= a.support
                if len(cloudedVars) > len(allVars)/2:
                    result = True
                    resultString = "Not tested because not concrete enough."
                else:
                    result = self.isRealizable(problem)
                    resultString = str(result)
            else:
                resultString = "Trivial Extension"
                result = True

        elapsed = (time.time() - start)
        shortTree = self.candidateTree.shortRepresentation()
        self.problem.report.flush()
        self.problem.report.write( "\\subsection{New Tree, comp.time: " + str(elapsed) + ", result: " + resultString + "}\n" +
                              self.candidateTree.tikzRepresentation() +
                              "\\\\\n\\noindent Short representation:" +
                              "\\begin{verbatim}" +
                              utils.breaklines(shortTree,72) +
                              "\\end{verbatim}\n" )
        return result


    def computeSuccessorCandidatesAtomic( self, subtree ):
        """ Refine a candidate solution tree at a leaf. To be changed whenever new
            operations are added.

            It returns a list of tuples, where the first element in the tuple is
            the additional (minimal) cost, and the second element is the new subtree """

        # Collect grammar rules
        # TODO: Change the overall computation such that a grammar-free "done" list is kept.
        #       -> This is to prevent double-checking a candidate solution tree if can be generated
        #          by different grammar rules.
        # TODO: Check that we don't consider abstract trees that cannot be concretized because
        #       its domain cannot be concretized with the grammar element here.
        #       -> Compute minimal and maximal supports needed for a sub-tree
        # TODO: We need some smart caching for the realizability of abstract solutions:
        #       - if for some subset of variables, an implementation is realizable, then
        #         also for the superset in the caresets
        #       - There are some partial concretizations that can never make the abstract
        #         solution unsatisfiable. This should be detected.

        nonTerminal = subtree.type.grammar.nonterminals[subtree.type.nonterminal]
        grammarRules = nonTerminal.productions
        # print ("RULES: ",grammarRules)

        # Apply all rules. We assume here that the grammar has already been flattened.
        for rule in grammarRules:

            # print ("Considering rule: ",rule)
            subtrees = []
            
            # We are sure that the rule is not a simple application of a non-terminal as the grammar
            # has already been preprocessed. So we must not have the non-terminal as a rule
            assert not rule[0] is None

            # Variable
            if rule[0]==synthesis.NodeType.VAR:
                # print ("This is a variable rule!")

                # Variable. Support has to be the variable for this to work.
                if len(subtree.support)!=1:
                    pass
                else:
                    # Find Variable
                    # utils.debug_breakpoint()
                    if rule[1] in subtree.support:
                        subClass = expression_sorts_and_types.ExpressionClass(subtree.type.grammar.findArgument(rule[1])["sort"], subtree.type.grammar,None)
                        yield (0,ProblemSolutionTreeNode(type=subClass,operation=synthesis.NodeType.VAR,support=subtree.support,children=[rule[1]]))

            elif rule[0]==synthesis.NodeType.CONST:
                # print ("This is a constant rule!")
                # Constant
                if len(subtree.support)>0:
                    pass # Yield nothing
                else:
                    subClass = expression_sorts_and_types.ExpressionClass(rule[2], subtree.type.grammar, None)
                    yield (0,ProblemSolutionTreeNode(type=subClass,operation=synthesis.NodeType.CONST,support=subtree.support,children=[rule[1]]))


            else:
                # print ("This is a nontrivial rule!")
                # All other non-trivial operations
                subsupports = utils.computeNSubsetTuplesWhoseUnionIsTheParameter(subtree.support,len(rule[1]))
                for subsupport in subsupports:

                    # self.problem.report.write("\\texttt{SupportAccept in "+utils.tex_escape(str(rule))+": "+utils.tex_escape(str(subsupport))+"}")

                    # Accepted by the support lambda function?
                    if (len(rule)<=2 or rule[2](subsupport)):
                        # self.problem.report.write("granted. \n\n")

                        allParts = []
                        for i in range(0,len(rule[1])):

                            thisChild = None

                            # Compute children. These are either 1) Const, 2) Var, or 3) Nonterminal
                            if rule[1][i][0]==None:
                                # Nonterminal
                                thisSubclass = expression_sorts_and_types.ExpressionClass(subtree.type.grammar.nonterminals[rule[1][i][1]].sort, subtree.type.grammar, rule[1][i][1])
                                thisChild = ProblemSolutionTreeNode(type=thisSubclass,support=subsupport[i],operation=expression_sorts_and_types.NodeType.NONE,children=[])
                            else:
                                print ("Found:",rule[1][i],file=sys.stderr)
                                raise Exception("Only non-terminals are allowed under operator applications")                        
                        
                            allParts.append(thisChild)

                        additionalCost = sum([max(len(a)*2-1,1) for a in subsupport])-max(len(subtree.support)*2-1,1)+1

                        yield (additionalCost,ProblemSolutionTreeNode(type=subtree.type,support=subtree.support,operation=rule[0],children=tuple(allParts)))
                    else:
                        # self.problem.report.write("denied. \n\n")
                        pass

        # End of going through the rules
        return
        yield


    def isRedundantInSearchOrder(self):
        """A function that returns TRUE if for some reason this CandidateExpressionTree is redundant in the search order. This
           could for example be the case if it is clear that this tree cannot become lexicographically minimal anymore."""

        # =================================================
        # Check 1: Violation of lexicographical minimality.
        # ================================================= 
        def lexicographicallySmaller(smallerNode,greaterNode):
            """ Can return 'None' if both nodes are the same """
            if not utils.total_set_order(smallerNode.support,greaterNode.support):
                return False
            if smallerNode.support != greaterNode.support:
                return True

            # Stop here is one of the nodes is not concretized yet -- then we are comparing apples and pears.
            if expression_sorts_and_types.NodeType.NONE in [smallerNode.operation,greaterNode.operation]:
                return True

            # Ok, the supports are the same. What about the number of parameters
            if (len(smallerNode.children) < len(greaterNode.children)):
                return True
            elif (len(smallerNode.children) > len(greaterNode.children)):
                return False

            # Ok, numbers of parameters is the same as well. Hmm, ok, what about the operation?
            if (smallerNode.operation.value.value < greaterNode.operation.value.value):
                return True
            elif (smallerNode.operation.value.value > greaterNode.operation.value.value):
                return False

            # Ok, is this a basic operation?
            if smallerNode.operation in [expression_sorts_and_types.NodeType.VAR,expression_sorts_and_types.NodeType.CONST]:
                if smallerNode.children == greaterNode.children:
                    return None
                return smallerNode.children <= greaterNode.children # Works in all cases (Int, Str, List(Int), List(Str), ...)

            # Hmm, ok, a complex operation. Let's recurse then.
            for i in range(0,len(smallerNode.children)):
                res = lexicographicallySmaller(smallerNode.children[i],greaterNode.children[i])
                if res == True:
                    return True
                elif res == False:
                    return False
            return None # Seems to be identical...


        def isRedundantInSearchOrderLexicographicalMinimalityRecurse(node):
            if node.operation==expression_sorts_and_types.NodeType.VAR:
                return False
            elif node.operation==expression_sorts_and_types.NodeType.CONST:
                return False
            elif node.operation.is_associative() and node.children[0].type.nonterminal == node.children[1].type.nonterminal:
                assert len(node.children)==2
                # Perform lexicographic comparison
                if lexicographicallySmaller(node.children[0],node.children[1])==False:
                    return True
            # In all other cases: Recurse into the tree
            for a in node.children:
                if isRedundantInSearchOrderLexicographicalMinimalityRecurse(a):
                    return True
            return False
                

        if isRedundantInSearchOrderLexicographicalMinimalityRecurse(self.candidateTree):
            return True

        # ================================================= 
        # No reason for redundancy found
        # =================================================
        return False               



class ProblemFixedGrammar(synthesis.Problem):
    def __init__(self,variables, relation, operations):
        super().__init__()
        self.variables = variables
        self.relation = relation
        self.operations = operations

    @classmethod
    def fromSygusBenchmark(cls, filename):
        variables, relation = sygus.read_benchmark_file(filename)
        return ProblemFixedGrammar(variables, relation, [])

    def inputs(self):
        inputs = []
        for name in self.variables:
            if self.variables[name]['type'] == 'in':
                inputs.append(name)
        return inputs

    def outputs(self):
        outputs = []
        for name in self.variables:
            if self.variables[name]['type'] == 'out':
                outputs.append(name)
        return outputs

    def perform_computation(self,configuration):

        '''The entry point into the problem solution. Popluates the candidate pools with initial nodes before running the 
           general perform_computation function.'''

        # Log the grammar to the TeX file
        self.report.write("\\section{Grammars used}\\begin{lstlisting}\n")
        for u in self.outputs():
            self.report.write("\n")
            self.report.write(str(self.variables[u]["grammar"]))
            self.report.write("\n\nWith simulation relation: ")
            self.report.write(str(self.variables[u]["grammar"].getSimulatorRelation()))
            self.report.write("\n")
        self.report.write("\end{lstlisting}\n")

        # List all combinations of supports for all output variables
        combinations = [[]]
        for u in self.outputs():
            oldCombinations = combinations
            combinations = []
            theseInputs = [a["name"] for a in self.variables[u]["grammar"].args]
            for num_elemens in range( 0, len(theseInputs)+1 ):
                for b in itertools.combinations(theseInputs,num_elemens):
                    for a in oldCombinations:
                        combinations.append(a+[b])

        # print ("Variables: ", self.variables)

        # For all combinations, add the tree to the candidate pool
        for a in combinations:
            cost = sum([max(len(b)*2-1,1) for b in a])

            # print ("Combination:",a," cost ",cost)
            outputVars = [(a,b) for (a,b) in self.variables.items() if b["type"]=="out"]

            rootTree = ProblemSolutionTreeNode(
                type = expression_sorts_and_types.ExpressionClass.makeTuple(),
                operation = expression_sorts_and_types.NodeType.TUPLE,
                support = None,
                children = [ProblemSolutionTreeNode(
                    type = expression_sorts_and_types.ExpressionClass(outputVars[i][1]["sort"][-1],outputVars[i][1]["grammar"],"Start"),
                    operation = expression_sorts_and_types.NodeType.NONE,
                    support = frozenset(a[i]),
                    children = []) for i in range(0,len(outputVars))])

            if not cost in self.candidate_pools:
                self.candidate_pools[ cost ] = []
            self.candidate_pools[ cost ].append( (True,ProblemSolutionTree.fromRootTreeNode( rootTree, self )) )

        super().perform_computation(configuration)
        
        # Print command
        if len(self.candidate_pools)>0:
            for solution in self.solution_pool:
                # Candidate Tree
                thisTree = solution.candidateTree
                assert thisTree.operation == expression_sorts_and_types.NodeType.TUPLE
                outputVars = [(a,b) for (a,b) in self.variables.items() if b["type"]=="out"]
                for i in range(0,len(thisTree.children)):
                    allArgs = ["("+str(u["name"])+" "+u["sort"].smt2TypeString()+")" for u in outputVars[i][1]["grammar"].args]
                    print("(define-fun "+outputVars[i][0]+"("+" ".join(allArgs)+")")
                    print("    "+thisTree.children[i].type.sort.smt2TypeString())
                    
                    def recurse(subtree):
                        if subtree.operation == expression_sorts_and_types.NodeType.VAR:
                            return str(subtree.children[0])
                        elif subtree.operation == expression_sorts_and_types.NodeType.CONST:
                            return smt2_utils.format_const(subtree.children[0],subtree.type.sort)
                        else:
                            return "(" + str(subtree.operation)+" "+" ".join([recurse(child) for child in subtree.children])+")"                                    
   
                    print("    "+recurse(thisTree.children[i])+")")
        else:
            print("(fail)")
