#!/usr/bin/env python3.4
# Stuffed Software Synthesis (SOSY)
# Copyright (C) 2009-2015  University of Bremen
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#
# @file sosy.py
#
# @authors Ruediger Ehlers
#          Heinz Riener
#
# @version 1.0
#

import smt2_synthesis
import smt2_utils
from optparse import OptionParser
import sys
import os

def error_checking_and_print_summary(problem):
    num_inputs = len(problem.inputs())
    num_outputs = len(problem.outputs())

    if num_outputs == 0:
        print('[e] no output has been found in the SYNTH-LIB instance')
        sys.exit(1)
    if num_inputs > 16:
        print('[e] too many inputs --- populating the candidate pool with more than 4096 elements')
        sys.exit(1)

    print('[i] #inputs:', num_inputs)
    print('[i] #outputs:', num_outputs)
    print('[i] operations:', len(problem.operations))
    print('[i] maximal costs:', problem.maximal_cost)

def main(sygusFilename, reportFilename):
    try:
        smt2_utils.setup_human_readable_printing()

        problem = smt2_synthesis.ProblemFixedGrammar.fromSygusBenchmark(sygusFilename)
        error_checking_and_print_summary(problem)
    except smt2_utils.IncorrectProblemException as e:
        print ("[e] ",e)
        sys.exit(1)

    if reportFilename!=None:
        problem.setReportFilename(reportFilename, sygusFilename) # The sygus file name is written into the report.
    try:
        problem.perform_computation([])
    finally:
        problem.closeReport()

############################################################################
# main
############################################################################

# if parsing of larger benchmarks fails due to Python's object
# recursion limit, increase this value
sys.setrecursionlimit(10000)

### process arguments
parser = OptionParser(usage="usage %prog [options] --input <file>")

parser.add_option('-i', '--input',     dest='input',      help='input file in SYGUS benchmark format (.sl) or a directory with many benchmarks')
parser.add_option('-o', '--output',    dest='output',     help='output file')
parser.add_option('-v', '--verbose',   dest='verbose',    help='verbose output', default=False, action='store_true')
parser.add_option('-r', '--report-file',dest='reportfile',help='LuaLaTeX report false')
parser.add_option('-q', '--quiet',     dest='quiet',      help='no output',      default=False, action='store_true')

opts, args = parser.parse_args()

### error checking and preparation
error = False

if opts.input == None:
    error = True
    print('[e] no input file specificed', file=sys.stderr)
else:
    if not os.path.exists(opts.input):
        error = True
        print("[e] ''{0}'' does not exist".format(opts.input), file=sys.stderr)
    elif os.path.isdir(opts.input):
        error = True
        print("[e] ''{0}'' is a directory".format(opts.input), file=sys.stderr)

### print error messages and exit
if error:
    parser.print_help()
    sys.exit(-1)

############################################################################

# calling main here avoids a complaint from Python about corruped
# double linked list
# print("Input file: ",opts.input,file=sys.stderr)
main(opts.input,opts.reportfile)
