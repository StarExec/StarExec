#!/usr/bin/env python3.4
# Stuffed Software Synthesis (SOSY)
# Copyright (C) 2009-2015  University of Bremen
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#
# @file run.py
#
# @authors Ruediger Ehlers
#          Heinz Riener
#
# @version 1.0
#

from enum import Enum
import multiprocessing
from optparse import OptionParser
import os
import subprocess
import sys

############################################################################
# benchmark script
############################################################################

def benchmark_file(filename,time,mem):
    name, ext = os.path.splitext(filename)
    cmd = 'runlim --time-limit={0} --real-time-limit={0} --space-limit={1} -o "{2}" ./sosy.py --quiet -i {3} -o {4}'.format(time,mem,filename+'.log',filename,filename+'.output')
    try:
        # print("Operating on: ",filename,file=sys.stderr) 
        log = subprocess.check_output([cmd],shell=True)
    except subprocess.CalledProcessError as e:
        # find status reading log file
        content = dict()
        with open(filename+'.log','r') as f:
            for line in f:
                prefix, space, line = line.partition(' ')
                key, value = line.split(':',1)
                content[key.strip()] = value.strip()

        if content['status'] == 'out of time':
            return filename,'T'
        elif content['status'] == 'out of memory':
            return filename,'M'
        elif content['status'] == 'segmentation fault':
            return filename,'E'
        elif content['status'] == 'ok':
            return filename,"e("+filename+")"
        return filename,'U'
    # terminated normally
    return filename,'+'

############################################################################
# main
############################################################################

### process arguments
parser = OptionParser(usage="usage %prog [options] --input <file|directory>")

parser.add_option('-i', '--input',     dest='input',      help='input file in SYGUS benchmark format (.sl) or a directory with many benchmarks')

parser.add_option('-t', '--timeout',   type=int, dest='timelim',    help='time limit (in s)',             default=10,    action='store')
parser.add_option('-m', '--memout',    type=int, dest='memlim',     help='memory limit (in MB)',          default=100,   action='store')
parser.add_option("-p", "--cpulimit",  type=int, dest="cpulimit",   help="limit the number of used CPUs", default=multiprocessing.cpu_count(), action="store")

parser.add_option('-v', '--verbose',   dest='verbose',    help='verbose output', default=False, action='store_true')
parser.add_option('-c', '--check',     dest='check',      help='check mode',     default=False, action='store_true')

opts, args = parser.parse_args()

###########################################################################

### error checking and preparation
error = False

if opts.input == None:
    error = True
    print('[e] no input file or input directory specificed', file=sys.stderr)
else:
    if not os.path.exists(opts.input):
        error = True
        print("[e] ''{0}'' does not exist".format(opts.input), file.sys.stderr)

### print error messages and exit
if error:
    parser.print_help()
    sys.exit(-1)

benchmarks = []
if os.path.isdir(opts.input):
    print("[i] search benchmark in directory in ''{0}''".format(opts.input))
    for root, dns, fns in os.walk(opts.input):
        benchmarks.extend(
            os.path.join(root, fn) for fn in fns if (sys.stdout.flush() or True) and fn.lower().endswith('.sl') and sys.stderr.write('.')
        )
    print('', file=sys.stderr)

    if opts.verbose:
        print('[i] found {0} benchmark files in SYGUS format'.format(len(benchmarks)))
        for b in benchmarks:
            print(b)
else:
    print("[i] input file ''{0}''".format(opts.input))
    benchmarks.append(opts.input)

print("[i] evaluation setup:", file=sys.stderr)
settings = [
    [ "#benchmarks:",                  str(len(benchmarks)) ],
    [ "time limit (per benchmark):",   str(opts.timelim), 's' ],
    [ "memory limit (per benchmark):", str(opts.memlim), 'MB' ],
    [ "CPU usage limit:",              str(opts.cpulimit)]
]
print( '\n'.join( [' '.join(s) for s in settings] ), file=sys.stderr )

### determine number of CPUs to use
cpus = 1
if multiprocessing.cpu_count() < opts.cpulimit:
    cpus = multiprocessing.cpu_count()
else:
    cpus = opts.cpulimit

### finally do the work with multiprocessing
print('[i] do synthesis (+ ... ok, T ... timeout, M ... memoryout, e ... error, E ... critical error, U ... unknown exit code)')
workers = multiprocessing.Pool(cpus)
results = [ workers.apply_async( benchmark_file, args=(filename,opts.timelim,opts.memlim) ) for filename in benchmarks ]
for r in results:
    if opts.verbose:
        print(r.get())
    else:
        print(r.get()[1],end='')
        sys.stdout.flush()
print('')
