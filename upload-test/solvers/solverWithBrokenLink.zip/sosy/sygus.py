#!/usr/bin/python3.4
# Stuffed Software Synthesis (SOSY)
# Copyright (C) 2009-2015  University of Bremen
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#
# @file sosy.py
#
# @authors Ruediger Ehlers
#          Heinz Riener
#
# @version 1.0
#
import expression_sorts_and_types
import smt2_utils
from sexprParser import sexp
import pyparsing
import re
import sys
import utils
import code
import synthesis
from grammar import optimized_grammar

############################################################################
# functions
############################################################################
def smt2string(sexpr, mapping = dict()):
    if isinstance(sexpr, list):
        result = '('
        for e in sexpr:
            result += smt2string(e, mapping) + ' '
        return result + ')'
    else:
        if isinstance(sexpr, tuple):
            # constant
            if sexpr[0] == 'Bool' and sexpr[1] == 0:
                return 'false'
            elif sexpr[0] == 'Bool' and sexpr[1] == 1:
                return 'true'
            elif sexpr[0] == 'Int':
                return str(sexpr[1])
            elif sexpr[0][0] == 'BitVec':
                return utils.binary(sexpr[1],'#b',sexpr[0][1][1])
            print(sexpr)
            assert False

        # substitute token if defined in mapping
        if (str(sexpr) in mapping):
            return mapping[str(sexpr)]
        else:
            return str(sexpr)

def smt2_pretty_string(sexpr, mapping = dict()):
    s = smt2string(sexpr, mapping)
    s = s.replace("(BitVec ", "(_ BitVec ")
    s = s.replace(" )", ")")
    # hacked to fix let expression parsing
    # add other types here
    s = s.replace(" Bool ", "  ")
    s = s.replace(" Int ", "  ")
    s = re.sub('\(_ BitVec [0-9]+\)','', s)
    return s

def extract_sort(i):
    if isinstance(i,pyparsing.ParseResults):
        if i[0] == "BitVec":
            return expression_sorts_and_types.ExpressionSort.fromString(i[0] + ':' + str(i[1][1]))
        else:
            return expression_sorts_and_types.ExpressionSort.fromString(i[0])
    else:
        return expression_sorts_and_types.ExpressionSort.fromString(i)

class synth_fun_grammar:
    def __init__(self, definition, user_defined_funs):
        assert definition[0] == 'synth-fun'
        self.user_defined_funs = user_defined_funs
        self.name = definition[1]
        self.args = []
        for a in definition[2]:
            self.args.append({'name':a[0],'sort':extract_sort(a[1])})
        self.sort = extract_sort(definition[3])

        vars = dict()
        # declare variables for arguments
        for arg in self.args:
            vars[arg['name']] = smt2_utils.declare_variable(arg['name'],arg['sort'])

        # pre-declare variables for nonterminal
        for ntdef in definition[4]:
            vars[ntdef[0]] = smt2_utils.declare_variable(ntdef[0], extract_sort(ntdef[1]))

        # print a list of user-defined function symbols
        print("[i] user-defined functions:")
        for f in self.user_defined_funs:
            print(f[1])

        # Read Non-terminals
        self.nonterminals = []
        for ntdef in definition[4]:
            productions = []
            assert len(ntdef) == 3 and "Not in SYGUS grammar"
            for p in ntdef[2]:
                if isinstance(p, pyparsing.ParseResults):
                    prod = p.asList()
                    pretty_string = smt2_pretty_string(prod)
                    for f in self.user_defined_funs:
                        if prod[0] == f[1]:
                            mapping = dict()
                            for x in zip(f[2],prod[1:]):
                                mapping[x[0][0]] = x[1]
                            pretty_string = smt2_pretty_string(f[4], mapping)
                    # formula
                    string = '(assert (= {0} {1}))'.format(ntdef[0],pretty_string)
                    # print('FORMULA',string)
                    tree = smt2_utils.expr_from_string(string, vars).arg(1)
                    productions.append(tree)
                elif isinstance(p, tuple):
                    # constant
                    string = '(assert (= {0} {1}))'.format(ntdef[0],smt2_pretty_string(p))
                    # print('CONSTANT',string)
                    tree = smt2_utils.expr_from_string(string, vars).arg(1)
                    productions.append(tree)
                elif isinstance(p, str):
                    # variable
                    string = '(assert (= {0} {1}))'.format(ntdef[0],p)
                    # print('VARIABLE',string)
                    tree = smt2_utils.expr_from_string(string, vars).arg(1)
                    productions.append(tree)
                else:
                    assert False and "Yet not implemented"

            # Translate production rules to internal (SMT-free) format
            def translateRuleToInternalFormat(rule):
                try:
                    op = expression_sorts_and_types.NodeType.fromString(rule.decl().name())
                    children = [translateRuleToInternalFormat(a) for a in rule.children()]
                    return (op,children)
                except ValueError:
                    # Oh, so this is not an operation...
                    print("[debug grammar]: '"+str(rule.decl().name())+"'")
                    if (str(rule.decl().name())=="bv") or (str(rule.decl().name())=="Int") or (str(rule.decl().name())=="true") or (str(rule.decl().name())=="false"):
                        # Constant
                        return (expression_sorts_and_types.NodeType.CONST,str(rule),expression_sorts_and_types.ExpressionSort.fromString(str(rule.sort())))
                    else:
                        print("[debug grammar B]: '"+str(rule.decl().name())+"'")
                        # Nonterminal
                        return (None,rule.decl().name())

            productions = [translateRuleToInternalFormat(a) for a in productions]
            nonterminal = {'name':ntdef[0], 'sort':extract_sort(ntdef[1]), 'productions':productions}
            self.nonterminals.append(nonterminal)

        # Go through all production rules and check for "None" node types
        # whether they are non-terminals or variables. Only keep the "None"
        # node types for non-terminals
        print("Pre_Grammar:",str(self))
        for a in self.nonterminals:
            for i in range(0,len(a["productions"])):
                print("IRULE:",a["productions"][i])
                def recurse(x):
                    if (x[0] is None):
                        foundNT = False
                        for b in self.nonterminals:
                            if b["name"]==x[1]:
                                foundNT = True
                        if foundNT:
                            return (x[0],x[1])
                        else:
                            # Variables must exist somewhere
                            foundVar = False
                            sortOfVar = None
                            for c in self.args:
                                if c["name"]==x[1]:
                                    foundVar = True
                                    sortOfVar = c["sort"]
                            if foundVar:
                                return (expression_sorts_and_types.NodeType.VAR,x[1],sortOfVar)
                            else:
                                raise Exception("Error in Grammar: Cannot identify the type of the sub-expression '"+x[1]+"' in production rule "+str(x))
                    elif (x[0]==expression_sorts_and_types.NodeType.CONST):
                        return x                    
                    else:
                        return (x[0],[recurse(b) for b in x[1]])
                
                a["productions"][i] = recurse(a["productions"][i])

        print("Post_Grammar:",str(self))
            

    def findProductionRules(self,name):
        for a in self.nonterminals:
            if a["name"] == name:
                return a
        raise Exception("Error: Did not find grammar rules for nonterminal "+name)

    def findArgument(self,name):
        for a in self.args:
            if a["name"] == name:
                return a
        raise Exception("Error: Did not find argument "+name+" in grammar.")


    def __str__(self):
        data = str(self.name)
        for arg in self.args:
            data += " ({0} {1})".format(arg['name'], arg['sort'])
        data += " --> " + str(self.sort) + '\n'
        for nt in self.nonterminals:
            data += '  ' + nt['name'] + ' ' + str(nt['sort']) + ' ' + str(nt['productions']) + '\n'
        return data

    def __repr__(self):
        return self.__str__()

def read_benchmark_file(filename):
    print('[i] read sygus benchmark file', filename)

    # remove comments and add surrounding brackets required by parser
    benchmark = '('
    with open(filename, 'r') as f:
        for line in f:
            line = line.split(';', 1)[0]
            benchmark += line
        benchmark += ')'

    sexpr = []
    try:
        benchmark = benchmark.replace('|','')
        benchmark = benchmark.replace(':','_')
        benchmark = benchmark.replace('$','_')
        benchmark = benchmark.replace('?','__')
        benchmark = re.sub(r'!(\d+)', lambda x: '_' + x.group(1), benchmark)
        benchmark = re.sub(r'@(\d+)', lambda x: '_' + x.group(1), benchmark)
        benchmark = re.sub(r'([^\s(])#([^x])', lambda x: x.group(1) + '_' + x.group(2), benchmark)
        benchmark = re.sub(r'([^\s(])#([^b])', lambda x: x.group(1) + '_' + x.group(2), benchmark)
        benchmark = re.sub(r'([\s\(])implies([\(\s])', lambda x: x.group(1) + " user_implies" + x.group(2), benchmark)
        benchmark = re.sub(r'([\s\(])iff([\(\s])', lambda x: x.group(1) + " user_iff" + x.group(2), benchmark)
        print(benchmark)
        sexpr = sexp.parseString(benchmark, parseAll=True)[0]
    except pyparsing.ParseException as e:
        print(benchmark)
        print('[e] parse error:', e, e.line)
        sys.exit(-1)

    # reconstruct SMT2 instance from SYGUS-LIB instance
    variables = dict()
    new_benchmark = ""
    synth_funs = dict()
    user_defined_funs = []
    for e in sexpr:
        if e[0] == 'define-fun':
            user_defined_funs.append(e.asList())
        if e[0] == 'constraint':
            e[0] = 'assert';
        if e[0] == 'synth-fun':
            name = e[1]
            args = e[2]
            return_type = e[3]
            ntdefs = e[4]

            # function arguments
            sort = [extract_sort(k[1]) for k in e[2]]

            # Grammar
            grammar = synth_fun_grammar(e, user_defined_funs)
            print("Grammar: ",grammar)
            grammar = optimized_grammar(grammar)
            grammar.performAllOptimizations()

            # function return type
            sort.append(extract_sort(e[3]))
            variables[e[1]] = {'sort':sort,'type':'out', 'grammar':grammar}

        elif e[0] == 'set-options':
            print('[w] ''set-options'' is not supported')
        elif e[0] == 'check-synth':
            pass
        elif e[0] == 'declare-var':
            variables[e[1]] = {'sort':[extract_sort(e[2])],'type':'in'}
        else:
            new_benchmark += smt2string(e.asList()) + '\n'

    new_benchmark = new_benchmark.replace("(BitVec ", "(_ BitVec ")
    new_benchmark = new_benchmark.replace("(extract ", "(_ extract ")
    new_benchmark = new_benchmark.replace(" )", ")")

    return variables, new_benchmark
