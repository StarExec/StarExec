# Stuffed Software Synthesis (SOSY)
# Copyright (C) 2009-2015  University of Bremen
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#
# @file tree_to_smt2.py
#
# @authors Ruediger Ehlers
#          Heinz Riener
#
# @version 1.0
#

import expression_sorts_and_types
import synthesis
import smt2_utils
import utils
import z3

# expr_cache: maps variables to constraints
# tree_cache: maps trees to constraints
def encodeTreeRecurse(tree, variables, constraints, expr_cache, tree_cache):
    if tree.operation == synthesis.NodeType.TUPLE:
        return [encodeTreeRecurse(child, variables, constraints, expr_cache, tree_cache) for child in tree.children]
    elif tree.operation == synthesis.NodeType.NONE:
        retval = smt2_utils.declare_variable('cloud' + str(utils.id()),tree.type.sort.smt2TypeString())
        expr_cache[retval.decl().name()] = retval
        tree_cache[tree.shortRepresentation()] = retval
        return retval
    elif tree.operation == synthesis.NodeType.VAR:
        assert len(tree.support) == 1
        assert len(tree.children) == 1
        retval = smt2_utils.declare_variable('var_' + str(utils.id()), tree.type.sort.smt2TypeString())
        var = variables[tree.children[0]]
        expr_cache[retval.decl().name()] = retval
        tree_cache[tree.shortRepresentation()] = retval
        constraints.append(retval == var)
        return retval
    elif tree.operation == synthesis.NodeType.CONST:
        assert len(tree.children) == 1
        if tree.type.sort.is_bool():
            retval = bool(tree.children[0])
        else:
            retval = int(tree.children[0])
        tree_cache[tree.shortRepresentation()] = retval
        return retval
    else:
        exprs = [encodeTreeRecurse(child, variables, constraints, expr_cache, tree_cache) for child in tree.children]
        retval = smt2_utils.declare_variable('var_' + str(utils.id()), tree.type.sort.smt2TypeString())
        expr_cache[retval.decl().name()] = retval
        tree_cache[tree.shortRepresentation()] = retval
        if tree.operation == synthesis.NodeType.NOT:
            constraints.append(retval == z3.Not(exprs[0]))
        elif tree.operation == synthesis.NodeType.BVNOT:
            constraints.append(retval == ~exprs[0])
        elif tree.operation == synthesis.NodeType.BVNEG:
            constraints.append(retval == (-exprs[0]))
        elif tree.operation == synthesis.NodeType.OR:
            constraints.append(retval == z3.Or(exprs[0],exprs[1]))
        elif tree.operation == synthesis.NodeType.AND:
            constraints.append(retval == z3.And(exprs[0],exprs[1]))
        elif tree.operation == synthesis.NodeType.XOR:
            constraints.append(retval == z3.Xor(exprs[0],exprs[1]))
        elif tree.operation == synthesis.NodeType.BVOR:
            constraints.append(retval == (exprs[0] | exprs[1]))
        elif tree.operation == synthesis.NodeType.BVAND:
            constraints.append(retval == (exprs[0] & exprs[1]))
        elif tree.operation == synthesis.NodeType.BVXOR:
            constraints.append(retval == (exprs[0] ^ exprs[1]))
        elif tree.operation == synthesis.NodeType.SUB or tree.operation == synthesis.NodeType.BVSUB:
            constraints.append(retval == (exprs[0] - exprs[1]))
        elif tree.operation == synthesis.NodeType.ADD or tree.operation == synthesis.NodeType.BVADD:
            constraints.append(retval == (exprs[0] + exprs[1]))
        elif tree.operation == synthesis.NodeType.MUL or tree.operation == synthesis.NodeType.BVMUL:
            constraints.append(retval == (exprs[0] * exprs[1]))
        elif tree.operation == synthesis.NodeType.EQ:
            constraints.append(retval == (exprs[0] == exprs[1]))
        elif tree.operation == synthesis.NodeType.LE:
            constraints.append(retval == (exprs[0] <= exprs[1]))
        elif tree.operation == synthesis.NodeType.LT:
            constraints.append(retval == (exprs[0] < exprs[1]))
        elif tree.operation == synthesis.NodeType.GE:
            constraints.append(retval == (exprs[0] >= exprs[1]))
        elif tree.operation == synthesis.NodeType.GT:
            constraints.append(retval == (exprs[0] > exprs[1]))
        elif tree.operation == synthesis.NodeType.ITE:
            constraints.append(retval == z3.If(exprs[0],exprs[1],exprs[2]))
        elif tree.operation == synthesis.NodeType.BVULT:
            constraints.append(retval == z3.ULT(exprs[0],exprs[1]))
        elif tree.operation == synthesis.NodeType.BVULE:
            constraints.append(retval == z3.ULE(exprs[0],exprs[1]))
        elif tree.operation == synthesis.NodeType.BVUGT:
            constraints.append(retval == z3.UGT(exprs[0],exprs[1]))
        elif tree.operation == synthesis.NodeType.BVUGE:
            constraints.append(retval == z3.UGE(exprs[0],exprs[1]))
        elif tree.operation == synthesis.NodeType.BVSLT:
            constraints.append(retval == (exprs[0] < exprs[1]))
        elif tree.operation == synthesis.NodeType.BVSLE:
            constraints.append(retval == (exprs[0] <= exprs[1]))
        elif tree.operation == synthesis.NodeType.BVSGT:
            constraints.append(retval == (exprs[0] > exprs[1]))
        elif tree.operation == synthesis.NodeType.BVSGE:
            constraints.append(retval == (exprs[0] >= exprs[1]))
        elif tree.operation == synthesis.NodeType.BVUREM:
            constraints.append(retval == z3.URem(exprs[0],exprs[1]))
        elif tree.operation == synthesis.NodeType.BVSREM:
            constraints.append(retval == z3.SRem(exprs[0],exprs[1]))
        elif tree.operation == synthesis.NodeType.BVUDIV:
            constraints.append(retval == z3.UDiv(exprs[0],exprs[1]))
        elif tree.operation == synthesis.NodeType.BVSDIV:
            constraints.append(retval == z3.SDiv(exprs[0],exprs[1]))
        elif tree.operation == synthesis.NodeType.BVSHL:
            constraints.append(retval == exprs[0] << exprs[1])
        elif tree.operation == synthesis.NodeType.BVASHR:
            constraints.append(retval == exprs[0] >> exprs[1])
        elif tree.operation == synthesis.NodeType.BVLSHR:
            constraints.append(retval == z3.LShR(exprs[0],exprs[1]))
        else:
            print(tree.operation)
            assert False and "yet not implemented tree.operation"
        return retval

def encode(tree, variables, constraints, expr_cache, tree_cache):
    return encodeTreeRecurse(tree.candidateTree, variables, constraints, expr_cache, tree_cache)

def smt2_expression_recurse(tree):
    if tree.operation == synthesis.NodeType.TUPLE:
        return [smt2_expression_recurse(child) for child in tree.children]
    elif tree.operation == synthesis.NodeType.NONE:
        assert False and "Not supported"
    elif tree.operation == synthesis.NodeType.VAR:
        assert len(tree.support) == 1
        assert len(tree.children) == 1
        return smt2_utils.declare_variable(tree.children[0], tree.type.sort.smt2TypeString())
    elif tree.operation == synthesis.NodeType.CONST:
        assert len(tree.children) == 1
        return int(tree.children[0])
    else:
        exprs = [smt2_expression_recurse(child) for child in tree.children]
        if tree.operation == synthesis.NodeType.NOT:
            return z3.Not(exprs[0])
        elif tree.operation == synthesis.NodeType.BVNOT:
            return (~exprs[0])
        elif tree.operation == synthesis.NodeType.BVNEG:
            return ((-exprs[0]))
        elif tree.operation == synthesis.NodeType.OR:
            return z3.Or(exprs[0],exprs[1])
        elif tree.operation == synthesis.NodeType.AND:
            return z3.And(exprs[0],exprs[1])
        elif tree.operation == synthesis.NodeType.XOR:
            return z3.Xor(exprs[0],exprs[1])
        elif tree.operation == synthesis.NodeType.BVOR:
            return ((exprs[0] | exprs[1]))
        elif tree.operation == synthesis.NodeType.BVAND:
            return ((exprs[0] & exprs[1]))
        elif tree.operation == synthesis.NodeType.BVXOR:
            return ((exprs[0] ^ exprs[1]))
        elif tree.operation == synthesis.NodeType.SUB or tree.operation == synthesis.NodeType.BVSUB:
            return ((exprs[0] - exprs[1]))
        elif tree.operation == synthesis.NodeType.ADD or tree.operation == synthesis.NodeType.BVADD:
            return ((exprs[0] + exprs[1]))
        elif tree.operation == synthesis.NodeType.MUL or tree.operation == synthesis.NodeType.BVMUL:
            return ((exprs[0] * exprs[1]))
        elif tree.operation == synthesis.NodeType.EQ:
            return ((exprs[0] == exprs[1]))
        elif tree.operation == synthesis.NodeType.LE:
            return ((exprs[0] <= exprs[1]))
        elif tree.operation == synthesis.NodeType.LT:
            return ((exprs[0] < exprs[1]))
        elif tree.operation == synthesis.NodeType.GE:
            return ((exprs[0] >= exprs[1]))
        elif tree.operation == synthesis.NodeType.GT:
            return ((exprs[0] > exprs[1]))
        elif tree.operation == synthesis.NodeType.ITE:
            return (z3.If(exprs[0],exprs[1],exprs[2]))
        elif tree.operation == synthesis.NodeType.BVULT:
            return (z3.ULT(exprs[0],exprs[1]))
        elif tree.operation == synthesis.NodeType.BVULE:
            return (z3.ULE(exprs[0],exprs[1]))
        elif tree.operation == synthesis.NodeType.BVUGT:
            return (z3.UGT(exprs[0],exprs[1]))
        elif tree.operation == synthesis.NodeType.BVUGE:
            return (z3.UGE(exprs[0],exprs[1]))
        elif tree.operation == synthesis.NodeType.BVSLT:
            return (exprs[0] < exprs[1])
        elif tree.operation == synthesis.NodeType.BVSLE:
            return (exprs[0] <= exprs[1])
        elif tree.operation == synthesis.NodeType.BVSGT:
            return (exprs[0] > exprs[1])
        elif tree.operation == synthesis.NodeType.BVSGE:
            return (exprs[0] >= exprs[1])
        elif tree.operation == synthesis.NodeType.BVUREM:
            return (z3.URem(exprs[0],exprs[1]))
        elif tree.operation == synthesis.NodeType.BVSREM:
            return (z3.SRem(exprs[0],exprs[1]))
        elif tree.operation == synthesis.NodeType.BVUDIV:
            return (z3.UDiv(exprs[0],exprs[1]))
        elif tree.operation == synthesis.NodeType.BVSDIV:
            return (z3.SDiv(exprs[0],exprs[1]))
        elif tree.operation == synthesis.NodeType.BVSHL:
            return (exprs[0] << exprs[1])
        elif tree.operation == synthesis.NodeType.BVASHR:
            return (exprs[0] >> exprs[1])
        elif tree.operation == synthesis.NodeType.BVLSHR:
            return (z3.LShR(exprs[0],exprs[1]))
        else:
            print(tree.operation)
            assert False and "yet not implemented tree.operation"

def smt2_expression(tree):
    return smt2_expression_recurse(tree.candidateTree)
