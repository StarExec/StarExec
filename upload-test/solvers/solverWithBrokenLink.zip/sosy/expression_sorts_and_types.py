#!/usr/bin/python3.4
# Stuffed Software Synthesis (SOSY)
# Copyright (C) 2009-2015  University of Bremen
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#
# @file utils.py
#
# @authors Ruediger Ehlers
#          Heinz Riener
#
# @version 1.0
#
from enum import Enum, unique

class ExpressionSort:

    class ExpressionSortEnum(Enum):
        # http://research.microsoft.com/en-us/um/redmond/projects/z3/z3.html#SortRef
        # UNINTERPRETED = 0
        BOOL = 1
        INT = 2
        # REAL = 3
        BV = 4
        # ARRAY = 5
        # DATATYPE = 6
        # RELATION = 7
        # FINITE_DOMAIN = 8
        UNKNOWN = 1000
        TUPLE = 1001 # Used to merge the multiple functions to be synthesized into a single string

    def __init__ (self, datatype, bitwidth):
        self.datatype = datatype
        self.bitwidth = bitwidth

    def __eq__( self, other ):
        return self.datatype!=self.ExpressionSortEnum.BV or self.bitwidth==other.bitwidth

    def __hash__( self):
        return 10000*self.datatype.value + self.bitwidth

    def dataTypeAndBitwidth(self):
        return (self.datatype,self.bitwidth)

    def is_bool(self):
        return self.datatype==self.ExpressionSortEnum.BOOL

    def is_int(self):
        return self.datatype==self.ExpressionSortEnum.INT
    
    def is_bitvector(self):
        return self.datatype==self.ExpressionSortEnum.BV

    def __str__( self ):
        if ( self.datatype == self.ExpressionSortEnum.BV ):
            return "bv:"+str(self.bitwidth)
        elif ( self.datatype == self.ExpressionSortEnum.TUPLE ):
            return "tuple"
        elif ( self.datatype == self.ExpressionSortEnum.BOOL ):
            return "bool"
        elif ( self.datatype == self.ExpressionSortEnum.INT ):
            return "int"
        elif ( self.datatype == self.ExpressionSortEnum.UNKNOWN ):
            return "unknown"
        else:
            raise Exception("Unknown ExpressionSort type")

    def smt2TypeString(self):
        if ( self.datatype == self.ExpressionSortEnum.BV ):
            return "(BitVec "+str(self.bitwidth)+")"
        elif ( self.datatype == self.ExpressionSortEnum.BOOL ):
            return "Bool"
        elif ( self.datatype == self.ExpressionSortEnum.INT ):
            return "Int"
        elif ( self.datatype == self.ExpressionSortEnum.TUPLE ):
            return "tuple"
        elif ( self.datatype == self.ExpressionSortEnum.UNKNOWN ):
            return "unknown"
        else:
            raise Exception("Unknown ExpressionSort type")

    @classmethod
    def fromString(cls, name):
        ''' This function returns a data type from a string. Used to interpret the types from the 
            SyGuS instances'''

        # There must only be at most one ":"
        assert len([a for a in name if a==":"])<=1

        name = name.lower()
        if name.startswith("bitvec:"):
            nofBits = int(name.split(":")[1])
            assert nofBits>0
            assert nofBits<=64 # More isn't supported for the time being
            return ExpressionSort(cls.ExpressionSortEnum.BV, nofBits)
        elif name.startswith("bitvec("):
            suffix = name.split("(")[1]
            assert ")" in suffix
            nofBits = int(suffix.split(")")[0])
            assert nofBits>0
            assert nofBits<=64 # More isn't supported for the time being
            return ExpressionSort(cls.ExpressionSortEnum.BV, nofBits)
        elif name=="bool":
            return ExpressionSort(cls.ExpressionSortEnum.BOOL,1)
        elif name=="int":
            return ExpressionSort(cls.ExpressionSortEnum.INT,-1)
        else:
            raise Exception( "No support for data type/sort ''" + name + "''" )

    @staticmethod
    def getTargetSort(nodetype,operandTypes):
        """ This method takes a set of operand types and computed to which type
            this operation would map the operandTypes """
        if nodetype.is_comparison_operator():
            # Comparison -> Check that params are the same and there are two
            assert len(operandTypes)==2
            assert operandTypes[0]==operandTypes[1]
            return ExpressionSort(ExpressionSort.ExpressionSortEnum.BOOL,1)
        if nodetype in [NodeType.CONST, NodeType.VAR]:
            raise Exception("Error: Cannot get TargetSort from atomic element")
        if nodetype.is_unary_type_preserving_operation():
            assert len(operandTypes)==1
            return operandTypes[0]
        if nodetype.is_binary_doubly_same_type_operation():
            assert len(operandTypes)==2
            assert operandTypes[0]==operandTypes[1]
            return operandTypes[0]
        if nodetype == NodeType.ITE:
            assert len(operandTypes)==3
            assert operandTypes[1]==operandTypes[2]
            return operandTypes[1]
        raise Exception("Error: Unsupported operation: " + str(nodetype))




# =================================================
# A class that represents a "type" of expression,
# where type not only means the data type (e.g.,
# integer), but also the grammar. So it consists
# of an ExpressionSort and a grammar/nonterminal
# =================================================
class ExpressionClass:

    # Fast lookup method for certain expression classes
    @classmethod
    def makeTuple(cls):
        return ExpressionClass(ExpressionSort(ExpressionSort.ExpressionSortEnum.TUPLE,None),None,None)

    def __init__ (self, sort, grammar, nonterminal):
        self.sort = sort
        self.grammar = grammar
        self.nonterminal = nonterminal

    def __eq__( self, other ):
        if self.nonterminal != other.nonterminal:
            return False
        if self.grammar != other.grammar:
            return False
        return self.sort == other.sort

    def dataTypeAndBitwidth(self):
        return (self.datatype,self.bitwidth)

    def __str__( self ):
        return str(self.sort)+":"+str(self.nonterminal)

    def visualizationTypeString( self ):
        return str(self.sort)+":"+str(self.nonterminal)

    @classmethod
    def fromString(sortString, grammar, nonterminal):
        ''' This function returns a data type from a string. Used to interpret the types from the 
            SyGuS instances'''
        return ExpressionClass(cls.ExpressionSort.fromString(sortString), grammar, nonterminal)



# =================================================
# Possible Expression Sorts
# =================================================
class NodeType:
    # Constants for types and operations
    # The operations can be arbitrary strings - in this case, they are custom functions...
    # TODO: Check for completeness and do a code review to check all individual cases in all switch statements in this class.
    
    class NodeTypeEnum(Enum):        
        NONE = 0
        LET = 8
        TUPLE = 9
        VAR, CONST, NOT, OR, AND, XOR, SUB, ADD, MUL, EQ, LE, LT, GE, GT = range(10,24)
        BVADD = 100
        BVMUL = 101
        BVAND = 102
        BVOR = 103
        BVSHL = 104
        BVSUB = 105
        BVXOR = 106
        BVNOT = 107
        BVNEG = 108
        BVLSHR = 109
        BVUDIV = 110
        BVUREM = 111
        BVULT = 112
        BVULE = 113
        BVUGT = 114
        BVUGE = 115
        BVSLT = 116
        BVSLE = 117
        BVSGT = 118
        BVSGE = 119
        BVASHR = 120
        BVSDIV = 121
        BVSREM = 122
        ITE = 200

    # Static set of custom functions
    customFunctions = set([])

    def __init__( self, value):
        self.value = value

    def __eq__( self, other ):
        if not isinstance(other, NodeType):
            return False
        return self.value == other.value

    def __hash__( self ):
        return str(self.value).__hash__()

    @classmethod
    def register_custom_function(cls,fn):
        assert isinstance(fn,str)
        NodeType.customFunctions.add(fn)

    def to_tex_string( self ):
        if isinstance(self.value,str):
            return self.value
        if self.value == self.NodeTypeEnum.LE:
            return "$\leq$"
        elif self.value == self.NodeTypeEnum.LT:
            return "$<$"
        if self.value == self.NodeTypeEnum.GE:
            return "$\geq$"
        elif self.value == self.NodeTypeEnum.GT:
            return "$>$"
        else:
            return str(self.value)

    def __repr__( self ):
        return "NodeType("+str(self.value)+")"

    def __str__( self ):
        if isinstance(self.value,str):
            return self.value
        if ( self.value == NodeType.NodeTypeEnum.NONE ):
            return "none"
        elif ( self.value == NodeType.NodeTypeEnum.VAR ):
            return "var"
        elif ( self.value == NodeType.NodeTypeEnum.CONST ):
            return "const"
        elif ( self.value == NodeType.NodeTypeEnum.NOT ):
            return "not"
        elif ( self.value == NodeType.NodeTypeEnum.AND ):
            return "and"
        elif ( self.value == NodeType.NodeTypeEnum.OR ):
            return "or"
        elif ( self.value == NodeType.NodeTypeEnum.XOR ):
            return "xor"
        elif ( self.value == NodeType.NodeTypeEnum.ADD ):
            return "+"
        elif ( self.value == NodeType.NodeTypeEnum.SUB ):
            return "-"
        elif ( self.value == NodeType.NodeTypeEnum.MUL ):
            return "*"
        elif ( self.value == NodeType.NodeTypeEnum.EQ ):
            return "=="
        elif ( self.value == NodeType.NodeTypeEnum.LT ):
            return "<"
        elif ( self.value == NodeType.NodeTypeEnum.LE ):
            return "<="
        elif ( self.value == NodeType.NodeTypeEnum.GT ):
            return ">"
        elif ( self.value == NodeType.NodeTypeEnum.GE ):
            return ">="
        elif ( self.value == NodeType.NodeTypeEnum.BVADD ):
            return "bvadd"
        elif ( self.value == NodeType.NodeTypeEnum.BVAND ):
            return "bvand"
        elif ( self.value == NodeType.NodeTypeEnum.BVMUL ):
            return "bvmul"
        elif ( self.value == NodeType.NodeTypeEnum.BVOR ):
            return "bvor"
        elif ( self.value == NodeType.NodeTypeEnum.BVSHL ):
            return "bvshl"
        elif ( self.value == NodeType.NodeTypeEnum.BVSUB ):
            return "bvsub"
        elif ( self.value == NodeType.NodeTypeEnum.BVXOR ):
            return "bvxor"
        elif ( self.value == NodeType.NodeTypeEnum.BVNOT ):
            return "bvnot"
        elif ( self.value == NodeType.NodeTypeEnum.BVNEG ):
            return "bvneg"
        elif ( self.value == NodeType.NodeTypeEnum.BVLSHR ):
            return "bvlshr"
        elif ( self.value == NodeType.NodeTypeEnum.BVUDIV ):
            return "bvudiv"
        elif ( self.value == NodeType.NodeTypeEnum.BVUREM ):
            return "bvurem"
        elif ( self.value == NodeType.NodeTypeEnum.BVULT ):
            return "bvult"
        elif ( self.value == NodeType.NodeTypeEnum.BVULE ):
            return "bvule"
        elif ( self.value == NodeType.NodeTypeEnum.BVUGT ):
            return "bvugt"
        elif ( self.value == NodeType.NodeTypeEnum.BVUGE ):
            return "bvuge"
        elif ( self.value == NodeType.NodeTypeEnum.BVSLT ):
            return "bvslt"
        elif ( self.value == NodeType.NodeTypeEnum.BVSLE ):
            return "bvsle"
        elif ( self.value == NodeType.NodeTypeEnum.BVSGT ):
            return "bvsgt"
        elif ( self.value == NodeType.NodeTypeEnum.BVSGE ):
            return "bvsge"
        elif ( self.value == NodeType.NodeTypeEnum.BVASHR ):
            return "bvashr"
        elif ( self.value == NodeType.NodeTypeEnum.BVSDIV ):
            return "bvsdiv"
        elif ( self.value == NodeType.NodeTypeEnum.BVSREM ):
            return "bvsrem"
        elif ( self.value == NodeType.NodeTypeEnum.ITE ):
            return "ite"
        elif ( self.value == NodeType.NodeTypeEnum.TUPLE ):
            return "tuple"
        else:
            raise Exception("Error: Unsupported type: "+str(self.value))

    def fromString( name ):
        name = name.lower()

        if name in NodeType.customFunctions:
            return NodeType(name)
        if name == "none":
            raise ValueError( "NONE types are not parsed directly in order to accidentally interpret 'none' as an SMT keyword!" )
        elif name == "var":
            raise ValueError( "VAR types are not parsed directly in order to accidentally interpret 'var' as an SMT keyword!" )
        elif name == "const":
            raise ValueError( "CONST types are not parsed directly in order to accidentally interpret 'const' as an SMT keyword!" )
        elif name == "not" or name == "!":
            return NodeType(NodeType.NodeTypeEnum.NOT)
        elif name == "and" or name == "&&":
            return NodeType(NodeType.NodeTypeEnum.AND)
        elif name == "xor" or name == "^":
            return NodeType(NodeType.NodeTypeEnum.XOR)
        elif name == "or" or name == "||":
            return NodeType(NodeType.NodeTypeEnum.OR)
        elif name == "add" or name == "+":
            return NodeType(NodeType.NodeTypeEnum.ADD)
        elif name == "sub" or name == "-":
            return NodeType(NodeType.NodeTypeEnum.SUB)
        elif name == "mul" or name == "*":
            return NodeType(NodeType.NodeTypeEnum.MUL)
        elif name == "eq" or name == "==" or name == "=":
            return NodeType(NodeType.NodeTypeEnum.EQ)
        elif name == "lt" or name == "<":
            return NodeType(NodeType.NodeTypeEnum.LT)
        elif name == "le" or name == "<=":
            return NodeType(NodeType.NodeTypeEnum.LE)
        elif name == "ge" or name == ">=":
            return NodeType(NodeType.NodeTypeEnum.GE)
        elif name == "gt" or name == ">":
            return NodeType(NodeType.NodeTypeEnum.GT)
        elif name == "if":
            return NodeType(NodeType.NodeTypeEnum.ITE)
        elif name == "bvadd":
            return NodeType(NodeType.NodeTypeEnum.BVADD)
        elif name == "bvand":
            return NodeType(NodeType.NodeTypeEnum.BVAND)
        elif name == "bvor":
            return NodeType(NodeType.NodeTypeEnum.BVOR)
        elif name == "bvmul":
            return NodeType(NodeType.NodeTypeEnum.BVMUL)
        elif name == "bvshl":
            return NodeType(NodeType.NodeTypeEnum.BVSHL)
        elif name == "bvsub":
            return NodeType(NodeType.NodeTypeEnum.BVSUB)
        elif name == "bvxor":
            return NodeType(NodeType.NodeTypeEnum.BVXOR)
        elif name == "bvnot":
            return NodeType(NodeType.NodeTypeEnum.BVNOT)
        elif name == "bvneg":
            return NodeType(NodeType.NodeTypeEnum.BVNEG)
        elif name == "bvudiv":
            return NodeType(NodeType.NodeTypeEnum.BVUDIV)
        elif name == "bvurem":
            return NodeType(NodeType.NodeTypeEnum.BVUREM)
        elif name == "bvlshr":
            return NodeType(NodeType.NodeTypeEnum.BVLSHR)
        elif name == "bvult":
            return NodeType(NodeType.NodeTypeEnum.BVULT)
        elif name == "bvule":
            return NodeType(NodeType.NodeTypeEnum.BVULE)
        elif name == "bvugt":
            return NodeType(NodeType.NodeTypeEnum.BVUGT)
        elif name == "bvuge":
            return NodeType(NodeType.NodeTypeEnum.BVUGE)
        elif name == "bvslt":
            return NodeType(NodeType.NodeTypeEnum.BVSLT)
        elif name == "bvsle":
            return NodeType(NodeType.NodeTypeEnum.BVSLE)
        elif name == "bvsgt":
            return NodeType(NodeType.NodeTypeEnum.BVSGT)
        elif name == "bvsge":
            return NodeType(NodeType.NodeTypeEnum.BVSGE)
        elif name == "bvashr":
            return NodeType(NodeType.NodeTypeEnum.BVASHR)
        elif name == "bvsdiv":
            return NodeType(NodeType.NodeTypeEnum.BVASHR)
        elif name == "bvsrem":
            return NodeType(NodeType.NodeTypeEnum.BVSREM)
        elif name == "let":
            return NodeType(NodeType.NodeTypeEnum.LET)
        else:
            raise ValueError( "No support for operation ''" + name.upper() + "''" )

    def is_binary_doubly_same_type_operation(self):
        # Which operations take two operands of some type t and produce an operand of type t?
        return self.value in [NodeType.NodeTypeEnum.BVADD, NodeType.NodeTypeEnum.BVMUL, NodeType.NodeTypeEnum.BVOR, NodeType.NodeTypeEnum.BVAND, NodeType.NodeTypeEnum.AND, NodeType.NodeTypeEnum.OR, NodeType.NodeTypeEnum.XOR, NodeType.NodeTypeEnum.ADD, NodeType.NodeTypeEnum.MUL, NodeType.NodeTypeEnum.BVSHL, NodeType.NodeTypeEnum.BVSUB, NodeType.NodeTypeEnum.BVXOR, NodeType.NodeTypeEnum.BVLSHR, NodeType.NodeTypeEnum.SUB, NodeType.NodeTypeEnum.BVUDIV, NodeType.NodeTypeEnum.BVUREM, NodeType.NodeTypeEnum.BVASHR, NodeType.NodeTypeEnum.BVSDIV, NodeType.NodeTypeEnum.BVSREM]

    def is_unary_type_preserving_operation(self):
        # Which operations take an operand of some type t and produce an operand of type t?
        return self.value in [NodeType.NodeTypeEnum.NOT, NodeType.NodeTypeEnum.BVNOT, NodeType.NodeTypeEnum.BVNEG]

    def is_standard_operation_for_tikz_output(self):
        # Which nodes are not special cases for the tikz output
        return not self.value in [ NodeType.NodeTypeEnum.CONST, NodeType.NodeTypeEnum.VAR, NodeType.NodeTypeEnum.TUPLE, NodeType.NodeTypeEnum.NONE ]

    def is_comparison_operator(self):
        # Which operations take two operands of some type t and produce a BOOL?
        return self.value in [ NodeType.NodeTypeEnum.LE, NodeType.NodeTypeEnum.GT, NodeType.NodeTypeEnum.EQ, NodeType.NodeTypeEnum.GE, NodeType.NodeTypeEnum.LT, NodeType.NodeTypeEnum.BVULT, NodeType.NodeTypeEnum.BVULE,  NodeType.NodeTypeEnum.BVUGT, NodeType.NodeTypeEnum.BVUGE, NodeType.NodeTypeEnum.BVSLT, NodeType.NodeTypeEnum.BVSLE, NodeType.NodeTypeEnum.BVSGT, NodeType.NodeTypeEnum.BVSGE]

    def is_associative_or_ite(self):
        return (self.value == NodeType.NodeTypeEnum.ITE) or self.is_associative()

    def is_associative(self):
        return self.value in [NodeType.NodeTypeEnum.BVADD, NodeType.NodeTypeEnum.BVMUL, NodeType.NodeTypeEnum.BVOR, NodeType.NodeTypeEnum.BVAND, NodeType.NodeTypeEnum.AND, NodeType.NodeTypeEnum.OR, NodeType.NodeTypeEnum.XOR, NodeType.NodeTypeEnum.ADD, NodeType.NodeTypeEnum.MUL, NodeType.NodeTypeEnum.BVXOR, NodeType.NodeTypeEnum.BVLSHR, NodeType.NodeTypeEnum.EQ]

# ===========================
# Initialize basic NodeTypes
# ===========================
NodeType.NONE = NodeType(NodeType.NodeTypeEnum.NONE)
NodeType.TUPLE = NodeType(NodeType.NodeTypeEnum.TUPLE)
NodeType.VAR = NodeType(NodeType.NodeTypeEnum.VAR)
NodeType.CONST = NodeType(NodeType.NodeTypeEnum.CONST)
NodeType.NOT = NodeType(NodeType.NodeTypeEnum.NOT)
NodeType.OR = NodeType(NodeType.NodeTypeEnum.OR)
NodeType.AND = NodeType(NodeType.NodeTypeEnum.AND)
NodeType.XOR = NodeType(NodeType.NodeTypeEnum.XOR)
NodeType.SUB = NodeType(NodeType.NodeTypeEnum.SUB)
NodeType.ADD = NodeType(NodeType.NodeTypeEnum.ADD)
NodeType.MUL = NodeType(NodeType.NodeTypeEnum.MUL)
NodeType.EQ = NodeType(NodeType.NodeTypeEnum.EQ)
NodeType.LE = NodeType(NodeType.NodeTypeEnum.LE)
NodeType.LT = NodeType(NodeType.NodeTypeEnum.LT)
NodeType.GE = NodeType(NodeType.NodeTypeEnum.GE)
NodeType.GT = NodeType(NodeType.NodeTypeEnum.GT)
NodeType.BVADD = NodeType(NodeType.NodeTypeEnum.BVADD)
NodeType.BVMUL = NodeType(NodeType.NodeTypeEnum.BVMUL)
NodeType.BVAND = NodeType(NodeType.NodeTypeEnum.BVAND)
NodeType.BVOR = NodeType(NodeType.NodeTypeEnum.BVOR)
NodeType.BVSHL = NodeType(NodeType.NodeTypeEnum.BVSHL)
NodeType.BVSUB = NodeType(NodeType.NodeTypeEnum.BVSUB)
NodeType.BVXOR = NodeType(NodeType.NodeTypeEnum.BVXOR)
NodeType.BVNOT = NodeType(NodeType.NodeTypeEnum.BVNOT)
NodeType.BVNEG = NodeType(NodeType.NodeTypeEnum.BVNEG)
NodeType.BVLSHR = NodeType(NodeType.NodeTypeEnum.BVLSHR)
NodeType.BVUDIV = NodeType(NodeType.NodeTypeEnum.BVUDIV)
NodeType.BVUREM = NodeType(NodeType.NodeTypeEnum.BVUREM)
NodeType.BVULT = NodeType(NodeType.NodeTypeEnum.BVULT)
NodeType.BVULE = NodeType(NodeType.NodeTypeEnum.BVULE)
NodeType.BVUGT = NodeType(NodeType.NodeTypeEnum.BVUGT)
NodeType.BVUGE = NodeType(NodeType.NodeTypeEnum.BVUGE)
NodeType.BVSLT = NodeType(NodeType.NodeTypeEnum.BVSLT)
NodeType.BVSLE = NodeType(NodeType.NodeTypeEnum.BVSLE)
NodeType.BVSGT = NodeType(NodeType.NodeTypeEnum.BVSGT)
NodeType.BVSGE = NodeType(NodeType.NodeTypeEnum.BVSGE)
NodeType.BVASHR = NodeType(NodeType.NodeTypeEnum.BVASHR)
NodeType.BVSDIV = NodeType(NodeType.NodeTypeEnum.BVSDIV)
NodeType.BVSREM = NodeType(NodeType.NodeTypeEnum.BVSREM)
NodeType.ITE = NodeType(NodeType.NodeTypeEnum.ITE)
NodeType.LET = NodeType(NodeType.NodeTypeEnum.LET)
