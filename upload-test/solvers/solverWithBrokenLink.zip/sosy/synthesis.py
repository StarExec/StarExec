#!/usr/bin/python3.4
# Stuffed Software Synthesis (SOSY)
# Copyright (C) 2009-2015  University of Bremen
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#
# @file synthesis.py
#
# @authors Ruediger Ehlers
#          Heinz Riener
#
# @version 1.0
#
import expression_sorts_and_types
from expression_sorts_and_types import NodeType
import threading
import utils
from enum import Enum, unique
from collections import namedtuple
import collections
import datetime
import tree_to_smt2

# =================================================
# Candidate solution tree node type
# =================================================
class CandidateSolutionTreeNode(namedtuple("CandidateSolutionTreeNode", ['type', 'operation', 'support', 'children'])):
    def __repr__(self):
        """Special 'toString' method for the ease of debugging."""
        data = "CSTN(type=" + str(self.type)
        data = data + ",\n     operation=" + str(self.operation)
        if self.operation == NodeType.NONE:
            data = data + " (Operation not yet defined)"
        elif self.operation == NodeType.VAR:
            data = data + " (OPERATION_VAR)"
        elif self.operation == NodeType.CONST:
            data = data + " (OPERATION_CONST)"
        elif self.operation.is_standard_operation_for_tikz_output():
            data = data + " " + str(self.operation)
        elif self.operation == NodeType.TUPLE:
            data = data + " (TUPLE)"
        else:
            raise Exception("Error in CandidateSolutionTreeNde.__repr__: NodeType "+str(self.operation)+" is not supported.")
        data = data + ",\n     support=" + str(self.support)
        data = data + ",\n     children:\n"
        for a in self.children:
            lines = str(a).split("\n")
            data = data + "      - " + lines[0] + "\n"
            for line in lines[1:]:
                data = data + "        " + line + "\n"
        data = data + "     )"
        return data

    def tikzRepresentationRecurse(self):
        if self.support is None:
            supportString = ""
        else:
            supportString = "$\{" + utils.tex_escape(",".join(self.support)) + "\}$"
        if self.operation == NodeType.NONE:
            nodeType = "\"" + supportString
            suffix = "[cloud, draw,cloud puffs=10,cloud puff arc=120, aspect=2]"
        elif self.operation == NodeType.CONST:
            nodeType = "\"const"
            suffix = ""
        elif self.operation == NodeType.VAR:
            assert len(self.support) == 1
            nodeType = "\"var"
            suffix = ""
        elif self.operation.is_standard_operation_for_tikz_output():
            nodeType = "\"" + self.operation.to_tex_string() + " " + supportString
            suffix = ""
        elif self.operation == NodeType.TUPLE:
            nodeType = "\"Tuple " + supportString
            suffix = "[shape=rectangle, rounded corners, fill=black!20!white, draw]"
        else:
            raise Exception("Error: Node type "+str(self.operation)+" is currently not supported by tikzRepresentationRecurse")

        nodeType = nodeType + "{\\tiny (" + utils.tex_escape(self.type.visualizationTypeString()) + ")}"

        allData = nodeType + "\"" + suffix + " -> {"
        first = True
        for a in self.children:
            if not first:
                allData = allData + ","
            else:
                first = False
            if isinstance(a, str):
                allData = allData + " \"" + utils.tex_escape(a) + "\""
            else:
                allData = allData + " " + a.tikzRepresentationRecurse()
        allData = allData + "}"
        return allData

    def tikzRepresentation(self):
        nodeText = self.tikzRepresentationRecurse()
        return "\\maxsizebox{\\columnwidth}{!}{\\begin{tikzpicture}\graph [tree layout, grow=down, fresh nodes, level distance=0.5in, sibling distance=0.5in] {" + nodeText + "}; \\end{tikzpicture}}"

    def shortRepresentation(self):
        """For debugging purposes only -- computes a short representation that can be used for equality checking"""
        if self.operation==NodeType.CONST:
            return "const("+utils.tex_escape(self.children[0])+")"
        if self.operation==NodeType.VAR:
            return "var("+utils.tex_escape(self.children[0])+")"
        if self.support is None:
            sortSupport = []
        else:
            sortSupport = list(self.support)
            sortSupport.sort()
        return str(self.type) + ";" + str(self.operation) + ";" + ",".join(
            [utils.tex_escape(str(a)) for a in sortSupport]) + ";" + ",".join([a.shortRepresentation() for a in self.children])

    def getVariablesInClouds(self):
        if self.operation == expression_sorts_and_types.NodeType.NONE:
            return self.support
        else:
            if isinstance(self.children, collections.Iterable):
                summed = set([])
                for c in self.children:
                    if isinstance(c,CandidateSolutionTreeNode):
                        summed |= c.getVariablesInClouds()
                return summed
            else:
                return frozenset([])


    def allowsAnyPossibleFunctionOverSupport(self,support):
        assert isinstance(self.support,frozenset)
        if self.operation == NodeType.VAR:
            return False
        if self.operation == NodeType.CONST:
            return False
        if self.operation == NodeType.NONE:
            # print("Support diff: ",support.difference(self.support))
            return len(support.difference(self.support))==0

        # TODO: if the left argument can produce anything, then so can the operation...
        # TODO: Special ITE

        if self.operation in [NodeType.BVADD, NodeType.ADD, NodeType.BVXOR, NodeType.BVNOT, NodeType.NOT, NodeType.XOR, NodeType.SUB, NodeType.EQ, NodeType.BVSUB, NodeType.BVNEG ]:
            # If one argument can produce anything, then this operation can produce anything
            for a in self.children:
                if a.allowsAnyPossibleFunctionOverSupport(self.support):
                    return True

        if self.operation in [NodeType.BVOR, NodeType.BVAND, NodeType.AND, NodeType.OR, NodeType.LE, NodeType.LT, NodeType.GE, NodeType.GT, NodeType.BVULT, NodeType.BVULE, NodeType.BVUGT, NodeType.BVUGE, NodeType.BVSLT, NodeType.BVSLE, NodeType.BVSGT, 
        NodeType.BVSGE]:
            # If All arguments can produce anything *and* at least one of the children has full support, then this operation can  
            # produce anything
            # print("Yey! Let's check!")
            isOk = True
            foundFullSupport = False
            for a in self.children:
                if a.support == self.support:
                    foundFullSupport = True
                    # print("Found full support! Great!")
                else:
                    pass
                    # print("Lack of support: ",a.support,self.support)
                if not a.allowsAnyPossibleFunctionOverSupport(a.support):
                    # print("Aaaah. A pity!")
                    isOk = False
            if foundFullSupport and isOk:
                return True

        return False

    def requiresRealizabilityCheck(self,originalTree, originalPath):
        """ This function computes if the given tree has been concretized in a way such that a realizability check needs
            to be performed. Some concretizations of trees don't need them, and we save the SMT solver calls in such a case."""

        # Sane environment
        assert isinstance(originalTree, CandidateSolutionTreeNode)
        assert self.operation!=None
        assert (len(originalPath)==0) or (originalTree.operation == self.operation)

        # Which operation?
        if originalTree.operation==NodeType.VAR:
            return True
        elif originalTree.operation==NodeType.CONST:
            return True

        # Now check if all possible functions are supported by the subtree....
        if not originalTree.operation==NodeType.TUPLE:        
            answer = self.allowsAnyPossibleFunctionOverSupport(self.support)
            if answer == True:
                return False

        # We didn't find an answer yet
        if len(originalPath)==0:
            # Ok, this is concrete and we didn't find a reason for why no additional check is needed
            return True
        else:
            return self.children[originalPath[0]].requiresRealizabilityCheck(originalTree.children[originalPath[0]],originalPath[1:])


# =================================================
# Candidate solution tree class
# =================================================
class CandidateSolutionTree:
    """A type for candidate solution tree.

       The tree is represented as nested 4-tuples with the following elements:
       1. The type of the tree
       2. The type of operation, which can be:
          - None, which means that the operation is not yet specified
          - OPERATION_VAR (use variable)
          - OPERATION_ADD (integer types only)
       3. The list of inputs that the subtree uses
       4. The sub-trees
    """

    # Settings to guide the search procedure
    PENALTY_COPYING_AN_INPUT_SET_TO_A_SUBTREE_FOR_A_BINARY_OPERATION = 2
    DEPTH_OF_ABSTRACT_NODE_IN_FULLY_CONCRETE_TREE = 1 << 30

    def __init__(self, problem, treeNode):
        assert isinstance(problem, Problem)
        assert isinstance(treeNode, CandidateSolutionTreeNode)
        self.problem = problem
        self.candidateTree = treeNode

    @classmethod
    def fromScratch(cls, problem, subsetOfInputsUsed, outputType):
        return cls.fromRoot(subsetOfInputsUsed, outputType, problem)

    def __repr__(self):
        return "CandidateSolution: " + str(self.candidateTree)

    def processCandidateSolution(self, needsAbstractEvaluation):
        """ Returns set of solutions and a set of new candidates (as tuples with their additional cost) """
        if self.evaluateAbstractSolution(self.problem, needsAbstractEvaluation):
            # Concretize tree
            (subpath, depth) = self.getPathToConcretizableElementAndItsLength(self.candidateTree)
            # print("Found subpath to concretizableElement:",subpath,"with cost",depth)
            if depth == CandidateSolutionTree.DEPTH_OF_ABSTRACT_NODE_IN_FULLY_CONCRETE_TREE:
                # This means that the tree is already concrete -- so it implements the correct specification.
                return ([self], [])
            else:
                listOfNewCandidates = self.computeSuccessorCandidates(subpath)
                # Global penalties for tree (e.g., to add some heavy cost to
                # solutions with 2 or more constants) could be added here.
                for (a, b, c) in listOfNewCandidates:
                    if c.isRedundantInSearchOrder():
                        self.problem.report.write("\\subsection{Redundant Tree (no.\ "+str(utils.id())+")}")
                        self.problem.report.write(c.candidateTree.tikzRepresentation())
                listOfNewCandidates = [(a, b, c) for (a, b, c) in listOfNewCandidates if not c.isRedundantInSearchOrder()]
                # print("NC: "+str(listOfNewCandidates))
                return ([], listOfNewCandidates)
        else:
            # Cannot be concretized
            return ([], [])


    @classmethod
    def fromRoot(cls, inputsUsed, roottype, problem):
        assert isinstance(problem, SoftwareSynthesisProblem)
        newData = cls(problem, CandidateSolutionTreeNode(roottype, NodeType.NONE, inputsUsed, []))
        return newData

    @classmethod
    def fromRootTreeNode(cls, treeNode, problem):
        assert isinstance(problem, Problem)
        assert isinstance(treeNode, CandidateSolutionTreeNode)
        newData = cls(problem, treeNode)
        return newData

    def __str__(self):
        return "CandidateSolutionTree: " + str(self.candidateTree)

    def getPathToConcretizableElementAndItsLength(self, subtree):
        # print("getPathToConcretizableElementAndItsLength called on: "+str(subtree))
        minDepth = self.DEPTH_OF_ABSTRACT_NODE_IN_FULLY_CONCRETE_TREE
        minPath = []
        if subtree.operation == NodeType.NONE:
            return ([], 1)
        elif subtree.operation == NodeType.VAR:
            return ([], minDepth)
        elif subtree.operation == NodeType.CONST:
            return ([], self.DEPTH_OF_ABSTRACT_NODE_IN_FULLY_CONCRETE_TREE)
        for i in range(0, len(subtree.children)):
            # print("ST:"+str(subtree))
            (subpath, depth) = self.getPathToConcretizableElementAndItsLength(subtree.children[i])
            if depth < minDepth:
                minDepth = depth
                minPath = [i] + subpath
        if minDepth == self.DEPTH_OF_ABSTRACT_NODE_IN_FULLY_CONCRETE_TREE:
            return ([], self.DEPTH_OF_ABSTRACT_NODE_IN_FULLY_CONCRETE_TREE)
        else:
            return (minPath, minDepth + 1)

    def isFullyConcrete(self):
        (path,depth) = self.getPathToConcretizableElementAndItsLength(self.candidateTree)
        return depth==self.DEPTH_OF_ABSTRACT_NODE_IN_FULLY_CONCRETE_TREE

    def setOrderLeq(self, firstset, secondset):
        # Check if the first subset is smaller
        firstSetAsList = list(set(firstset).difference(set(secondset)))
        firstSetAsList.sort()
        secondSetAsList = list(set(secondset).difference(set(firstset)))
        secondSetAsList.sort()
        isSmaller = None
        firstSetPointer = 0
        secondSetPointer = 0
        # print("Candidate: ",firstSetAsList,secondSetAsList)
        if (len(firstSetAsList) > 0) and (len(secondSetAsList) > 0):
            diff = firstSetAsList[firstSetPointer] < secondSetAsList[secondSetPointer]
            if firstSetAsList[firstSetPointer] < secondSetAsList[secondSetPointer]:
                isSmaller = True
            elif firstSetAsList[firstSetPointer] > secondSetAsList[secondSetPointer]:
                isSmaller = False
        elif (firstSetPointer < len(firstSetAsList)):
            isSmaller = False
        elif (secondSetPointer < len(secondSetAsList)):
            isSmaller = True
        return isSmaller or isSmaller is None  # The second case is for set equality, which we allow here


    def getOrderedPairsOfSubsets(self, theset):
        """ Special order on the subsets for avoiding solution redundancy -- considers the differences between the sets"""
        solutionSet = []
        for firstset in utils.powerset(theset):
            for secondset in utils.powerset(theset):
                if self.setOrderLeq(firstset, secondset):
                    solutionSet.append((frozenset(firstset), frozenset(secondset)))
        return solutionSet

    def getUnorderedPairsOfSubsets(self, theset):
        """ Special order on the subsets for avoiding solution redundancy -- considers the differences between the sets"""
        solutionSet = []
        for firstset in utils.powerset(theset):
            for secondset in utils.powerset(theset):
                solutionSet.append((frozenset(firstset), frozenset(secondset)))
        return solutionSet

    def computeSuccessorCandidates(self, path):
        """Computes tuples of cost values and successor candidate trees in
           the search space for solutions."""
        # print("Path to the node to be replaced: "+str(path))
        pairs = self.computeSuccessorCandidatesRecurse(self.candidateTree, path)
        # print ("NofSuccessorCandidates:",len(pairs))
        return [(b.requiresRealizabilityCheck(self.candidateTree, path), a, self.__class__(self.problem, b)) for (a, b) in pairs]

    def computeSuccessorCandidatesRecurse(self, subtree, remainingpath):

        """Recursive worker function for 'computeSuccessorCandidates'."""
        if remainingpath == []:
            assert subtree.operation == NodeType.NONE
            # Refine this subtree
            # print(subtree)
            results = self.computeSuccessorCandidatesAtomic(subtree)
            return results
        else:
            # Recurse
            index = remainingpath[0]
            candidates = self.computeSuccessorCandidatesRecurse(subtree[3][index], remainingpath[1:])
            results = []
            for (cost, subsubtree) in candidates:
                assert isinstance(subsubtree, CandidateSolutionTreeNode)
                newTree = CandidateSolutionTreeNode(subtree.type, subtree.operation, subtree.support,
                           list(subtree.children[0:index]) + [subsubtree] + list(subtree.children[index + 1:]))
                results.append((cost, newTree))
            return results


# =================================================
# Worker Thread
# =================================================
def do_work(currentCost, candidatePools, solutionPool, syncLock, syncEvent, workingThreadWorking, nr, problem):
    while True:
        # Check for work
        with syncLock:
            # Found a solution already? Then we can return
            if len(solutionPool) > 0:
                syncEvent.set()
                return
            if len(candidatePools[currentCost]) > 0:
                todo = candidatePools[currentCost].pop()
            else:
                todo = None
        # Perform work
        if (todo != None):
            # print("Processing element: ",todo)
            b = todo
            try:
                (newSolutions, newCandidates) = b[1].processCandidateSolution(b[0])
                # time.sleep(1)
                with syncLock:
                    problem.nofCandidateTreesConsideredSoFar += 1
                    for (requiresRealizabilityCheck, newCost, newCandidate) in newCandidates:
                        if not newCost + currentCost in candidatePools:
                            candidatePools[newCost + currentCost] = []
                        # print("Inserting "+str(newCandidate)+" at "+str(newCost+currentCost))
                        candidatePools[newCost + currentCost].append((requiresRealizabilityCheck,newCandidate))
                    solutionPool.extend(newSolutions)
                syncEvent.set()
            except Exception as e:
                print("[e] Exception thrown!")
                print("=========================================\nException: ",e)
                import traceback
                traceback.print_exc()
                print("\n=========================================")
                with syncLock:
                    problem.maxNofCandidateTreesBeforeTermination = -1 # Terminate

        # Wait for more work
        if (todo == None) or (problem.nofCandidateTreesConsideredSoFar > problem.maxNofCandidateTreesBeforeTermination):
            with syncLock:
                workingThreadWorking.remove(nr)
                if len(workingThreadWorking) == 0:
                    syncEvent.set()
                    return
                else:
                    syncEvent.clear()
            syncEvent.wait()
            with syncLock:
                if len(workingThreadWorking) == 0:
                    # Nobody is doing anything and we've just been awakened.
                    return
                workingThreadWorking.add(nr)


# =================================================
# Candidate solution tree class
# =================================================
class Problem:
    def __init__(self):
        self.candidate_pools = {}
        self.solution_pool = []
        self.maximal_cost = 100
        self.query_timeout = 10
        self.report = utils.NullFileObject()
        self.nofCandidateTreesConsideredSoFar = 0
        self.maxNofCandidateTreesBeforeTermination = 2500

    def setReportFilename(self,reportFilename, inputFilename):
        self.report = open( reportFilename, 'w' )

        # Prepare LuaTeX overview output
        self.report.write("\\documentclass[a4paper,DIV18]{scrartcl}\n" \
                              "\\usepackage{tikz}\n" \
                              "\\usetikzlibrary{graphdrawing,graphs,shapes}\n" \
                              "\\usegdlibrary{trees}\n" \
                              "\\usepackage{adjustbox}\n" \
                              "\\usepackage{listings}\n\\lstset{breaklines=true,basicstyle=\\ttfamily}\n" \
                              "\\begin{document}\n" \
                              "\\title{Toast log of considered solutions: " + utils.tex_escape(inputFilename) + "}" \
                              "\\date{"+datetime.datetime.now().strftime("%I:%M%p on %B %d, %Y")+"}\\maketitle\n")

    def closeReport(self):
        self.report.write("\\end{document}\n")
        self.report.close()

    def perform_computation(self,configuration):
        print('[i] perform computation')
        print("[i] config:",configuration)

        # Start work
        workingThreadWorking = set([])
        syncLock = threading.Lock()
        syncEvent = threading.Event()
        NOF_SEARCH_THREADS = 1

        while len(self.candidate_pools) > 0 and (len(self.solution_pool) == 0) and (self.nofCandidateTreesConsideredSoFar <= self.maxNofCandidateTreesBeforeTermination):
            threads = []
            currentCost = min(self.candidate_pools.keys())
            if currentCost <= self.maximal_cost:
                self.report.write("\n\\section{Possible solutions with cost " + str(currentCost) + "}\n")
                currentWorkList = self.candidate_pools[currentCost]
                for i in range(0, NOF_SEARCH_THREADS):
                    thread = threading.Thread(target=do_work, args=(
                        currentCost, self.candidate_pools, self.solution_pool, syncLock, syncEvent, workingThreadWorking,
                        i,self))
                    with syncLock:
                        workingThreadWorking.add(i)
                    thread.start()
                    threads.append(thread)
                for thread in threads:
                    thread.join()
                print("Finished considering the solutions with cost " + str(currentCost))
                assert ((len(currentWorkList) == 0) or (len(self.solution_pool) > 0) or (self.nofCandidateTreesConsideredSoFar > self.maxNofCandidateTreesBeforeTermination))
                self.candidate_pools.pop(currentCost)
            else:
                break
        print("[i] terminating computation with",len(self.candidate_pools),"more cost levels to explore,",len(self.solution_pool),"many solutions found, and",self.nofCandidateTreesConsideredSoFar,"candidate trees considered.")
        for s in self.solution_pool:
            print('[i] solution:', tree_to_smt2.smt2_expression(s))
