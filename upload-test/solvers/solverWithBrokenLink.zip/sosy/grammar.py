#!/usr/bin/python3.4
# Stuffed Software Synthesis (SOSY)
# Copyright (C) 2009-2015  University of Bremen
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#
# @file utils.py
#
# @authors Ruediger Ehlers
#          Heinz Riener
#
# @version 1.0
#
from collections import namedtuple
from expression_sorts_and_types import NodeType
from expression_sorts_and_types import ExpressionSort
import copy, sys, utils


class optimized_grammar_nonterminal(namedtuple("optimized_grammar_nonterminal", ['sort', 'productions'])):
    
    def __new__(_cls, sort, productions):
        assert isinstance(productions,frozenset)
        return namedtuple("optimized_grammar_nonterminal", ['sort', 'productions'])(sort,productions)

class optimized_grammar:
    
    """SyGuS grammar optimizer.
       This class takes a standard grammar and simplifies it into a special normal form that allows to perform various optimizations.

       The grammar given to the optimizer has to be in form of a synth_fun_grammar, as defined in sygus.py

       The grammar is modified and analyzed in the following ways:
       1. It is modified such that all rules are atomic, i.e., only introduce at most one operator into the syntax tree
       2. For every grammar rule, upper and lower bounds on variable usable are computed.
       3. --To be determined--


       Fields of this class that implement a grammar:
       ==============================================
       - name: The name of the function whose grammar this is
       - sort: The type of the output of this grammar
       - nonterminals: The grammar. The non-terminals are a dict that maps non-terminal names to optimized_grammar_nonterminal.
                       After the construction, all rules are used in an atomic way.

       A grammar rule is a nested tuple, where the left-most element of each tuple element is a synthesis.NodeType, which represents
       the operation. If the operation is "None", then the second tuple element must be a string that is a valid non-terminal. The
       third element may be a lambda function that maps a list/tuple of supports to those that are allowed by the rule.

       There has to exist a nonterminal named "Start", whose sort is equal to the sort of the class.

       Additional fields:
       ==================
       brokenDownRulePrefix - All rules that were introduced when breaking down the grammar into its elemental form have this Prefix.

    """

    def __str__(self):
        result = "optimized_grammar(\n"
        result = result + "  name: "+self.name+"\n"
        result = result + "  sort: "+str(self.sort)+"\n"
        result = result + "  arguments: "+str(self.args)+"\n"
        result = result + "  productions:\n"
        for p in self.nonterminals.keys():
            result = result + "    "+p+":"+str(self.nonterminals[p].sort)+" ::= "+" | ".join("("+",".join([str(u) for u in b])+")" for b in self.nonterminals[p].productions)+"\n"
        return result

    def __init__(self, startingPoint):

        """ Builds the optimized_grammar object from the sygus.py grammar "draft" object. 
            Already breaks the grammar into pieces (so that all grammar rules are simple, i.e.,
            do not consist of more than one recursion level). However, the grammar is
            not analyzed and actually optimized yet."""

        # Initialize with the Starting point
        self.name = startingPoint.name
        assert isinstance(self.name,str)
        self.args = startingPoint.args
        self.sort = startingPoint.sort
        assert isinstance(self.sort,ExpressionSort)
        self.nonterminals = {} # Maps names namestuples("sort","production")
        
        # Obtain a safe prefix for the names of all newly introduced rules
        self.brokenDownRulePrefix = "_r"
        done = False
        while not done:
            done = True 
            for a in startingPoint.nonterminals:
                if self.brokenDownRulePrefix in a["name"]:
                    done = False
            if not done:
                self.brokenDownRulePrefix += str(len(self.brokenDownRulePrefix))
        self.brokenDownRulePrefix += "_"

        # Recursively break down rules into atomic forms. For the time being, ignore the fact that
        # some rules may be trivial afterwards. While breaking down the rules, make sure that
        # all production sets become FROZENSETS.
        def recurse(rule,baseName): # Returns (rule,sort)
            # print(rule,file=sys.stderr)
            if rule[0] is None:
                # Other non-terminal: Look up the type in this case
                for a in startingPoint.nonterminals:
                    if a["name"]==rule[1]:
                        return (rule,a["sort"])
            assert isinstance(rule[0],NodeType)
            if rule[0] in [NodeType.CONST, NodeType.VAR]:
                # Return the rule (plus its type in addition)
                assert isinstance(rule[-1],ExpressionSort)
                return (rule,rule[-1]) # Atomic case
            else:
                # Break up the rule
                newElements = []
                newSorts = []
                for a in rule[1]:
                    (newRule,newSort) = recurse(a,baseName)
                    addedRuleName = baseName+str(utils.id())
                    self.nonterminals[addedRuleName] = optimized_grammar_nonterminal(newSort,frozenset([newRule]))
                    newElements.append((None,addedRuleName))
                    newSorts.append(newSort)
                return ((rule[0],tuple(newElements)),ExpressionSort.getTargetSort(rule[0],newSorts))
                
        for nonterminal in startingPoint.nonterminals:
            newProductionRules = []
            for a in nonterminal["productions"]:
                (newRule,newType) = recurse(a,nonterminal["name"]+self.brokenDownRulePrefix)
                assert newType == nonterminal["sort"]
                newProductionRules.append(newRule)
            assert not nonterminal["name"] in self.nonterminals.keys()
            self.nonterminals[nonterminal["name"]] = optimized_grammar_nonterminal(sort=nonterminal["sort"],productions=frozenset(newProductionRules))

    def getNamesOfAllArguments(self):
        return [a["name"] for a in self.args]
                        
    def removeSingleNonterminalRighthandRules(self):
        """ Modifies the grammar such that on no right-hand side in a production rule, only a single non-terminal is
            present.

            This function is able to deal correctly with circular references.
        """
        # Saturate
        foundChange = True
        while foundChange:
            foundChange = False
            nonterminalNames = list(self.nonterminals.keys())
            for ntName in nonterminalNames:
                oldSizeProdRules = len(self.nonterminals[ntName].productions)
                addedRules = []
                for prod in self.nonterminals[ntName].productions:
                    if (prod[0]==None):
                        # Other non-terminal.
                        addedRules.extend(self.nonterminals[prod[1]].productions)
                if len(addedRules)>0:
                    addedRules.extend(self.nonterminals[ntName].productions)
                    self.nonterminals[ntName] = optimized_grammar_nonterminal(sort=self.nonterminals[ntName].sort,productions=frozenset(addedRules))
                    if len(self.nonterminals[ntName].productions)>oldSizeProdRules:
                        foundChange = True

        # Finally, remove the now superfluous single-applications
        for ntName in nonterminalNames:
            newProd = []
            for prod in self.nonterminals[ntName].productions:
                if (prod[0]!=None):
                    # Other non-terminal.
                    newProd.append(prod)
            self.nonterminals[ntName] = optimized_grammar_nonterminal(sort=self.nonterminals[ntName].sort,productions=frozenset(newProd))
    
    def removeDuplicateNonterminals(self):
        """ This function removes all nonterminals that have precisely the same sort and the same production rules.

            Crucial to be called after removeSingleNonterminalRighthandRules
        """
        # This function may need multiple passes, as only when merging equivalent nodes, others may be seen to be equivalent
        foundChange = True
        while foundChange:
            foundChange = False


            nonterminalNames = list(self.nonterminals.keys())
            nameRemapping = {}
            for i in range(0,len(nonterminalNames)):
                for j in range(i+1,len(nonterminalNames)):
                    
                    if self.nonterminals[nonterminalNames[i]]==self.nonterminals[nonterminalNames[j]]:
                        if self.brokenDownRulePrefix in nonterminalNames[i]:
                            nameRemapping[nonterminalNames[j]] = nonterminalNames[j]
                            nameRemapping[nonterminalNames[i]] = nonterminalNames[j]
                        else:
                            nameRemapping[nonterminalNames[j]] = nonterminalNames[i]
                            nameRemapping[nonterminalNames[i]] = nonterminalNames[i]
                if not nonterminalNames[i] in nameRemapping.keys():
                    nameRemapping[nonterminalNames[i]] = nonterminalNames[i]

            # Now, remove the trivial rules
            for i in range(0,len(nonterminalNames)):
                productions = self.nonterminals[nonterminalNames[i]].productions
                if len(productions)==1:
                    for a in productions:
                        if a[0]==None:
                            assert len(a)==2
                            nameRemapping[nonterminalNames[i]] = a[1]

            # Saturate the name remapping (Not sure if this is actually needed!)
            saturated = False
            while not saturated:
                saturated = True
                for a in nameRemapping.keys():
                    if nameRemapping[a]!=a:
                        b = nameRemapping[a]
                        if nameRemapping[b]!=b:
                            nameRemapping[a] = nameRemapping[b]
                            saturated = False

            # Perform the remapping 
            newNonterminals = {}
            for a in nonterminalNames:
                if nameRemapping[a]==a:
                    newProductionRules = []
                    for b in self.nonterminals[a].productions:
                        def recurse(rule):
                            if rule[0] is None:
                                assert len(rule)==2
                                return (None,nameRemapping[rule[1]])
                            elif rule[0] in [NodeType.CONST, NodeType.VAR]:
                                return rule
                            else:
                                return (rule[0],tuple([recurse(c) for c in rule[1]]))+rule[2:]
                        newProductionRules.append(recurse(b))
                    newNonterminals[a] = optimized_grammar_nonterminal(sort=self.nonterminals[a].sort,productions=frozenset(newProductionRules))
                else:
                    foundChange = True
            self.nonterminals = newNonterminals
                    
    def lookup_nonterminal_from_productions(self,sort,productions):
        """This function returns the name of a non-terminal that has the given sort and productions. It the non-terminal
           doesn't exist, it is added.

           As this functions needs to check support lambda functions, it is a bit more complicated than one would expect.
            """
        totalArguments = self.getNamesOfAllArguments()
        for (a,b) in self.nonterminals.items():
            if (b.sort==sort):
                assert isinstance(productions,frozenset)
                assert isinstance(b.productions,frozenset)
                # Check if all production rules are the same. As we have support-lambdas, the check is a bit more
                # expensive than we would expect
                miss = False
                for (base,ref) in [(productions,b.productions),(b.productions,productions)]:
                    for ruleBase in base:
                        found = False
                        for ruleRef in ref:
                            if ruleRef[0]==NodeType.VAR:
                                found = found or (ruleBase==ruleRef)
                            if ruleRef[0]==NodeType.CONST:
                                found = found or (ruleBase==ruleRef)
                            else:
                                # An operation mapping to nonterminals
                                if (not found) and (not miss):
                                    if ruleBase[0:2]==ruleRef[0:2]:
                                        # Now check the support
                                        if len(ruleBase)+len(ruleRef)>4:
                                            subsupports = utils.computeNSubsetTuplesWhoseUnionIsTheParameter(totalArguments,len(ruleBase[1]))
                                            found = True # Set to false later if not equal
                                            for subsupport in subsupports:
                                                # Check if a allows more than b in terms of support.
                                                # Not all rules may have a support at this point.
                                                if (len(ruleBase)==2 or ruleBase[2](subsupport)) != (len(ruleRef)==2 or ruleRef[2](subsupport)):
                                                    found = False
                                        else:
                                                # No support specification.
                                                found = True
                        if not found:
                            miss = True
                if not miss:
                    return a
        newName = self.brokenDownRulePrefix+"_lookup_"+str(utils.id())
        self.nonterminals[newName] = optimized_grammar_nonterminal(sort,productions)
        return newName

    def makeAssociativeOperatorsAndSomeOthersRightHeavy(self):
        """Modifies the grammar such that certain operations are right-heavy, i.e., such that the same operation cannot occur on
           the last operand again. Mostly, these are the associative operators, but also some others (such as ITE), where this
           is safe. This only works if the last two operands have the same non-terminal (i.e., all except for the
           condition in ITE).

           This function only removes the operator from the second-to-right-most operand if the right two operands (i.e.,
           everything except for the ITE condition) use the same non-terminal *and* they include the current rule. Not including
           the current rule may rule out solutions.

           This function requires that no lambdas on the order of elements are given yet, and returns rules that use lambdas.
        """
               
        # The list of non-terminals can change during this operation.
        replacedRules = {} # map from tuple (rulename,rule) to targetRule
        for ntName in utils.iterator_for_keyset_in_dict_that_works_on_dicts_on_which_elements_are_continuously_added(self.nonterminals):
            # print("Checking the folloing Nonterminal for replacements:",ntName)
            oldSizeProdRules = len(self.nonterminals[ntName].productions)
            newRules = []
            for a in self.nonterminals[ntName].productions:
                # print("Current rule:",a)
                assert a[0]!=None
                if (a[0].is_associative_or_ite()  # Operation is supported
                  and (((a[0]==NodeType.ITE) and (len(a[1])==3)) or (len(a[1])==2)) # Number of operands OK
                  and ((a[1][-1][0]==None) and (a[1][-2][0]==None)) # All operands are non-terminals
                  and (a[1][-1][1]==a[1][-2][1]) # The same grammar is given.
                  and ((a in self.nonterminals[a[1][-1][1]].productions) # and the current rule can be recursively applied
                    or ((a[1][-1][1],a) in replacedRules))):    # or was able to be recursively applied
                    # Use the rule in a left-heavy way
                    assert len(a)==2 # No lambdas may be given yet.
                    if not (a in self.nonterminals[a[1][-2][1]].productions):
                        # The original rule has already been removed.
                        assert (a[1][-1][1],a) in replacedRules
                        newRules.append(replacedRules[(a[1][-1][1],a)])
                    else:
                        # Use a new rule
                        newRightNonterminal = self.lookup_nonterminal_from_productions(self.nonterminals[a[1][-2][1]].sort,self.nonterminals[a[1][-2][1]].productions.difference([a]))
                        sys.stdout.flush()
                        newRule = (a[0],a[1][0:-2]+((None,newRightNonterminal),a[1][-1]), lambda x,u=len(a[1])-2,v=len(a[1])-1: utils.total_set_order(x[u],x[v]) )
                        replacedRules[(ntName,a)] = newRule
                        newRules.append(newRule)
                        assert newRightNonterminal != ntName
                    # print("Replacing rule",a,"of nonterminal",ntName,"by",newRules[-1])
                    # print("where we have started with the base nonterminal: ",a[1][-2][1]," and made a ",newRightNonterminal," out of it")
                else:
                    newRules.append(a)
            newRules = frozenset(newRules)
            if newRules != self.nonterminals[ntName].productions:
                self.nonterminals[ntName] = optimized_grammar_nonterminal(sort=self.nonterminals[ntName].sort,productions=frozenset(newRules))
                # print("New Grammar:",self)
                # print("RuleRep: ",replacedRules)



    def areConstNodesEqual(self,constNode1,constNode2):
        """Comparator function for constant nodes in grammars"""
        assert constNode1[0] is NodeType.CONST
        assert constNode2[0] is NodeType.CONST
        # TODO: Replace the following check by something more systematic
        return str(constNode1)==str(constNode2)

    def getSimulatorRelation(self):
        """Computes a simulation relation. It consists of tuples such that a tuple (a,b) consisting on nonterminal names a and b
           means that a simulates b, so that everything that can be represented as an expression of type b can also be represented
           as an expression of type b."""

        totalArguments = self.getNamesOfAllArguments()

        # Initialize with all non-terminals that have the same sort
        simulation = set([])
        for a in self.nonterminals.keys():
            for b in self.nonterminals.keys():
                if self.nonterminals[a].sort == self.nonterminals[b].sort:
                    simulation.add((a,b))

        # Standard greatest fixed point loop for computing simulations
        oldNofSim = 0
        while len(simulation)!=oldNofSim:
            oldNofSim = len(simulation)
            for a in self.nonterminals.keys():
                for b in self.nonterminals.keys():
                    if (a,b) in simulation:
                        # Check if it can stay in the simulation relation
                        # For that, try to find a rule of b that a cannot match
                        noSimulation = False
                        for pb in self.nonterminals[b].productions:
                            found = False
                            for pa in self.nonterminals[a].productions:
                                if pa[0]==pb[0]:
                                    # Ok, the types are the same. What about the values?
                                    if pa[0] is NodeType.CONST:
                                        if self.areConstNodesEqual(pa,pb):
                                            found = True
                                    elif pa[0] is NodeType.VAR:
                                        if pa[1]==pb[1]:
                                            found = True
                                    else:
                                        # All parameters are non-terminals. Then check the non-terminal list
                                        # for simulation
                                        if len(pa[1])==len(pb[1]):
                                            okSoFar = True
                                            for i in range(0,len(pa[1])):
                                                assert pa[1][i][0] is None
                                                assert pb[1][i][0] is None
                                                if not (pa[1][i][1],pb[1][i][1]) in simulation:
                                                    okSoFar = False
                                            if okSoFar:
                                                # Check if the two rules agree on the supported supports
                                                subsupports = utils.computeNSubsetTuplesWhoseUnionIsTheParameter(totalArguments,len(pb[1]))
                                                for subsupport in subsupports:
                                                    # Check if a allows more than b in terms of support.
                                                    # Not all rules may have a support at this point.
                                                    if len(pb)==2 or pb[2](subsupport):
                                                        if len(pa)>2 and not pa[2](subsupport):
                                                            okSoFar = False

                                            if okSoFar:
                                                found = True
                            if not found:
                                noSimulation = True
                        if noSimulation:
                            simulation.remove((a,b))
        return simulation

    def removeReferencesToSuperfluousConstants(self):
        """Sometimes, it doesn't make any sense to try to fill in certain constants into an expression. An example for this is
           the expression "x + 0". For some grammar non-terminal "N", we would want to only allow such operations if this is the only
           way in which we can translate a non-terminal type for "x" to "N". This procedure modifies the grammar to remove such 
           occurrences.

           Note that applying this procedure increases the number of grammar non-terminals substantially. However, the procedure
           always terminates as added non-terminals always have less production rules than the original ones.

           The procedure actually works on a lot of operation/constant pairs.

           DOES NOT DO ANYTHING WITH "ITE" YET.
           """

        # Define what precisely we are searching for.
        # -> All operations need to be BINARY

        def debugMe(sort,constant):
            utils.debug_breakpoint()
            return False
            
        badOperatorConstants = {
            NodeType.BVOR: (lambda sort,constant: str(constant)=="0"),
            NodeType.BVAND: (lambda sort,constant: ((int(constant)+1) == (1 << sort.bitwidth))),
            # NodeType.BVAND: debugMe,
            NodeType.ADD: (lambda sort,constant: str(constant)=="0"),
            NodeType.MUL: (lambda sort,constant: str(constant)=="1"),
            NodeType.BVADD: (lambda sort,constant: str(constant)=="0"),
            NodeType.BVMUL: (lambda sort,constant: str(constant)=="1"),
        }

        # Iterate through the grammar rules and replace rules that the "stupid constants"
        for nonterminal in utils.iterator_for_keyset_in_dict_that_works_on_dicts_on_which_elements_are_continuously_added(self.nonterminals):

            simulation = self.getSimulatorRelation()

            # print("Checking Const: ",nonterminal)
            acceptedProductions = []
            for rule in self.nonterminals[nonterminal].productions:
                if not rule[0] in badOperatorConstants:
                    # Rule does not have a bad constant. Then we just accept it
                    acceptedProductions.append(rule)
                else:
                    # Check if there exists the bad constant in the *left* target terminal
                    okRulesTarget = []
                    canModify = False
                    # print("rule:",rule)
                    assert rule[1][0][0] is None
                    targetNonterminal = rule[1][0][1]
                    # print ("Nonterminal is: ",targetNonterminal)
                    for ruleB in self.nonterminals[targetNonterminal].productions:
                        # print("Nonterminal rule of ",targetNonterminal,"is",ruleB)
                        if ruleB[0] is NodeType.CONST and (badOperatorConstants[rule[0]](self.nonterminals[targetNonterminal].sort,ruleB[1])):
                            # We need to disallow this one
                            canModify = True
                        else:
                            okRulesTarget.append(ruleB)

                    # If "canModify" is True, the we need to check if the grammar non-terminals allow the optimization
                    # This is the case if the *right* non-terminal does not allow more rules than the *current*
                    # nonterminal. So let's check this...
                    # print("Rule:",rule)
                    assert rule[1][1][0] is None
                    assert isinstance(rule[1][1][1],str)
                    assert isinstance(nonterminal,str)
                    if not (nonterminal,rule[1][1][1]) in simulation:
                        canModify = False

                    # Modify the current rule if this makes sense
                    if canModify:
                        # print("Rule *CAN* be modified!")
                        modifiedNonTerminal = self.lookup_nonterminal_from_productions(self.nonterminals[targetNonterminal].sort,frozenset(okRulesTarget))
                        # print("Looked up nonterminal:",modifiedNonTerminal)
                        acceptedProductions.append((rule[0],((None,modifiedNonTerminal),)+rule[1][1:])+rule[2:])
                    else:
                        acceptedProductions.append(rule)
            self.nonterminals[nonterminal] = optimized_grammar_nonterminal(self.nonterminals[nonterminal].sort,frozenset(acceptedProductions))


    def removeReferencesToOperationNullifyingConstants(self):
        """Sometimes, it doesn't make any sense to try to fill in certain constants into an expression if there is a constant that
           would do the trick as well. For example, we wouldn't allow "x*0" if constant 0 can be used directly.
        """

        # Define what precisely we are searching for.
        # -> All operations need to be BINARY

        def debugMe(sort,constant):
            utils.debug_breakpoint()
            return False
            
        # For every constant, we list 1. The disallowed constant, and 2. the constant that must be in the current production to
        #                                disallow this rule.
        badOperatorConstants = {
            NodeType.BVAND: ((lambda sort,constant: str(constant)=="0"),(lambda sort,constant: ((int(constant)+1) == (1 << sort.bitwidth)))),
            NodeType.BVOR: ((lambda sort,constant: ((int(constant)+1) == (1 << sort.bitwidth))),(lambda sort,constant: str(constant)=="0"))
        }

        for nonterminal in utils.iterator_for_keyset_in_dict_that_works_on_dicts_on_which_elements_are_continuously_added(self.nonterminals):

            simulation = self.getSimulatorRelation()

            # print("Checking Const: ",nonterminal)
            acceptedProductions = []
            for rule in self.nonterminals[nonterminal].productions:
                if not rule[0] in badOperatorConstants:
                    # Rule does not have a bad constant. Then we just accept it
                    acceptedProductions.append(rule)
                else:
                    # Check if the alternative constant can be deduced for this non-terminal as well.
                    otherConstantChecker = badOperatorConstants[rule[0]][1]
                    otherConstantFound = False
                    for otherRules in self.nonterminals[nonterminal].productions:
                        if otherRules[0]==NodeType.CONST:
                            if (otherConstantChecker(self.nonterminals[nonterminal].sort,otherRules[1])):
                                otherConstantFound = True
                    
                    if otherConstantFound:
                        # Check if there exists the bad constant in the *left* target terminal
                        okRulesTarget = []
                        canModify = False
                        # print("rule:",rule)
                        assert rule[1][0][0] is None
                        targetNonterminal = rule[1][0][1]
                        # print ("Nonterminal is: ",targetNonterminal)
                        for ruleB in self.nonterminals[targetNonterminal].productions:
                            # print("Nonterminal rule of ",targetNonterminal,"is",ruleB)
                            if ruleB[0] == NodeType.CONST and (badOperatorConstants[rule[0]][0](self.nonterminals[targetNonterminal].sort,ruleB[1])):
                                # We need to disallow this one
                                canModify = True
                            else:
                                okRulesTarget.append(ruleB)

                        # If "canModify" is True, the we need to check if the grammar non-terminals allow the optimization
                        # This is the case if the *right* non-terminal does not allow more rules than the *current*
                        # nonterminal. So let's check this...
                        # print("Rule:",rule)
                        assert rule[1][1][0] is None
                        assert isinstance(rule[1][1][1],str)
                        assert isinstance(nonterminal,str)
                        if not (nonterminal,rule[1][1][1]) in simulation:
                            canModify = False

                        # Modify the current rule if this makes sense
                        if canModify:
                            # print("Rule *CAN* be modified!")
                            modifiedNonTerminal = self.lookup_nonterminal_from_productions(self.nonterminals[targetNonterminal].sort,frozenset(okRulesTarget))
                            # print("Looked up nonterminal:",modifiedNonTerminal)
                            acceptedProductions.append((rule[0],((None,modifiedNonTerminal),)+rule[1][1:])+rule[2:])
                        else:
                            acceptedProductions.append(rule)
                    else:
                        # Toerh constant not found.
                        acceptedProductions.append(rule)
            self.nonterminals[nonterminal] = optimized_grammar_nonterminal(self.nonterminals[nonterminal].sort,frozenset(acceptedProductions))


    def removeDoubleNegation(self):
        """Modifies the grammar such that no double-negation is possible anymore"""

        # We list operations that allow double-negation here
        badOperators = [
            NodeType.BVNEG,
            NodeType.BVNOT,
            NodeType.NOT
        ]

        for nonterminal in utils.iterator_for_keyset_in_dict_that_works_on_dicts_on_which_elements_are_continuously_added(self.nonterminals):

            simulation = self.getSimulatorRelation()

            # print("Checking Doubly Neg: ",nonterminal)
            acceptedProductions = []
            for rule in self.nonterminals[nonterminal].productions:
                if not rule[0] in badOperators:
                    # Rule does not have a bad constant. Then we just accept it
                    # print("Double neg not bad operator:",rule[0])
                    acceptedProductions.append(rule)
                else:
                    # Assert that we have a non-terminal application here
                    assert len(rule[1])==1
                    assert rule[1][0][0]==None 
                    otherNonterminal = rule[1][0][1]

                    # Build a new copy of the other rule such that double-negation is not possible
                    newCopy = []
                    # print("DoubleNeg recursing into",otherNonterminal)
                    for newRule in self.nonterminals[otherNonterminal].productions:

                        # Another operator? Just add that to the new copy
                        if newRule[0] != rule[0]:
                            newCopy.append(newRule)

                        # ...but do a closer look at NOTs
                        else:
                            assert len(newRule[1])==1
                            assert newRule[1][0][0]==None 
                            thirdNonterminal = newRule[1][0][1]
                            # print("Double Neg checking simulation relation between",nonterminal,thirdNonterminal)
                            if (nonterminal,thirdNonterminal) in simulation:
                                # Don't add to the new copy if we found a double-negation
                                # print("Found simulation!")
                                pass
                            else:
                                newCopy.append(newRule)
                    
                    newNonterminal = self.lookup_nonterminal_from_productions(self.nonterminals[otherNonterminal].sort,frozenset(newCopy))
                    # print("New Nonterminal:",newNonterminal)
                    # We don't have to deal with the support sets here as the support sets in the sub-rule are always *smaller*.
                    acceptedProductions.append((rule[0],((None,newNonterminal),))+rule[2:])
                
                # Done with the current non-terminal
            self.nonterminals[nonterminal] = optimized_grammar_nonterminal(self.nonterminals[nonterminal].sort,frozenset(acceptedProductions))


    def removeRedundantConstantConstruction(self):
        """ For example, we shouldn't allow not(True) in a grammar in production rules that also allow a False.
            This rule must come relatively early in the sequence, so that when excluding rules of the form (x + 0),
            we don't miss the case that (x + NEG(MAX_INT)) would also build this result. """
        badConstantDetectors = {
            NodeType.BVNOT:(lambda sort,constant1,constant2: ((int(constant1)+1) == ((1 << sort.bitwidth)-int(constant2))))
        }
        
        for nonterminal in utils.iterator_for_keyset_in_dict_that_works_on_dicts_on_which_elements_are_continuously_added(self.nonterminals):

            # print("Checking Superfluous Constant-Neg: ",nonterminal)
            acceptedProductions = []
            for rule in self.nonterminals[nonterminal].productions:
                if not rule[0] in badConstantDetectors:
                    # Rule does not have a complementor. Then we just accept it
                    acceptedProductions.append(rule)
                else:
                    
                    # Assert that we have a non-terminal application here
                    assert len(rule[1])==1
                    assert rule[1][0][0]==None 
                    otherNonterminal = rule[1][0][1]

                    # Build a new copy of the other rule such that the said constant cannot be built with negating another constant
                    newCopy = []
                    # print("ConstantNeg recursing into",otherNonterminal)
                    for newRule in self.nonterminals[otherNonterminal].productions:
                        # A non-const? Then it is good to do.
                        if newRule[0] != NodeType.CONST:
                            newCopy.append(newRule)

                        # ...but do a closer look at Constants...
                        else:
                            foundBadConstant = False
                            # No go through the constants of "nonterminal" and check if we found a "matching" constant
                            for ruleB in self.nonterminals[nonterminal].productions:
                                if ruleB[0]==NodeType.CONST:
                                    # print("Checking bad constant pair: ",newRule[1],ruleB[1])
                                    if badConstantDetectors[rule[0]](newRule[2],newRule[1],ruleB[1]):
                                        # print("Found bad constant pair: ",newRule[1],ruleB[1])
                                        foundBadConstant = True
                            if not foundBadConstant:
                                newCopy.append(newRule)
                    
                    newNonterminal = self.lookup_nonterminal_from_productions(self.nonterminals[otherNonterminal].sort,frozenset(newCopy))
                    # print("New Nonterminal:",newNonterminal)
                    # We don't have to deal with the support sets here as the support sets in the sub-rule are always *smaller*.
                    acceptedProductions.append((rule[0],((None,newNonterminal),))+rule[2:])
                
                # Done with the current non-terminal
            self.nonterminals[nonterminal] = optimized_grammar_nonterminal(self.nonterminals[nonterminal].sort,frozenset(acceptedProductions))

    def addUpperAndLowerBoundsForSupports(self):
        """ Makes sure that non-terminals are only ever used with supports for which they can actually be expanded."""

        # Initialize lower and upper bounds
        lowerBounds = {}
        upperBounds = {}
        for a in self.nonterminals:
            lowerBounds[a] = frozenset([a["name"] for a in self.args])
            upperBounds[a] = frozenset([])

        # Compute lower bounds
        changed = True
        while changed:
            changed = False
            for nonterminal in self.nonterminals:
                lowerBoundsThisOne = set([a["name"] for a in self.args])
                for rule in self.nonterminals[nonterminal].productions:
                    if rule[0]==NodeType.CONST:
                        lowerBoundsThisOne = set([])
                    elif rule[0]==NodeType.VAR:
                        lowerBoundsThisOne = lowerBoundsThisOne.intersection([rule[1]])
                    else:
                        # Nonterminal
                        allLowerBounds = set([])
                        for (op,newNt) in rule[1]:
                            assert op==None
                            allLowerBounds |= lowerBounds[newNt]
                        lowerBoundsThisOne = lowerBoundsThisOne.intersection(allLowerBounds)
                if lowerBoundsThisOne!=lowerBounds[nonterminal]:
                    changed = True
                    lowerBounds[nonterminal] = frozenset(lowerBoundsThisOne)
         
        # Compute upper bounds   
        changed = True
        while changed:
            changed = False
            for nonterminal in self.nonterminals:
                upperBoundsThisOne = set([])
                for rule in self.nonterminals[nonterminal].productions:
                    if rule[0]==NodeType.CONST:
                        pass
                    elif rule[0]==NodeType.VAR:
                        upperBoundsThisOne.add(rule[1])
                    else:
                        # Nonterminal
                        for (op,newNt) in rule[1]:
                            assert op==None
                            upperBoundsThisOne |= upperBounds[newNt]
                if upperBoundsThisOne!=upperBounds[nonterminal]:
                    changed = True
                    upperBounds[nonterminal] = frozenset(upperBoundsThisOne)

        # Print the bounds
        # print("Computed bounds:")
        # for a in self.nonterminals:
        #   print ("Lower bound for",a,":",lowerBounds[a])
        #   print ("Upper bound for",a,":",upperBounds[a])
         
        # Update the rules according to the bounds computed
        for nonterminal in self.nonterminals:
            acceptedProductions = []
            for rule in self.nonterminals[nonterminal].productions:
                if rule[0]==NodeType.VAR or rule[0]==NodeType.CONST:
                    acceptedProductions.append(rule)
                else:
                    minimax = [] # The bounds for this Rule
                    for (a,b) in rule[1]:
                        assert a==None # Is a non-terminal
                        minimax.append((lowerBounds[b],upperBounds[b]))

                    # Function to be used in the lambdas for minimax checking
                    def checkMinimax(x,u):
                        for i in range(0,len(x)):
                            if not (x[i] >= u[i][0]):
                                return False
                            if not (x[i] <= u[i][1]):
                                return False
                        return True

                    if len(rule)>2: # Already have a lambda...
                        acceptedProductions.append(rule[0:2]+((lambda x,u=minimax,o=rule[2]: o(x) and checkMinimax(x,u)),))
                    else:
                        acceptedProductions.append(rule[0:2]+((lambda x,u=minimax: checkMinimax(x,u)),))

            self.nonterminals[nonterminal] = optimized_grammar_nonterminal(self.nonterminals[nonterminal].sort,frozenset(acceptedProductions))


    def enforceSupportOrderedNessOnBinaryAssociativeOperations(self):
        """ Sometimes, a grammar can have rules of the form "A --> B or B", which are not captured by the
            'make applications-of-the-same-operation-right-heavy' optimization of this class.
            In this case, we want to enforce that the supports are ordered correctly"""
        for nonterminal in utils.iterator_for_keyset_in_dict_that_works_on_dicts_on_which_elements_are_continuously_added(self.nonterminals):

            # print("Support Modifier: ",nonterminal)
            acceptedProductions = []
            for rule in self.nonterminals[nonterminal].productions:
                if (not rule[0].is_associative()):
                    # Rule is not associative. Then we just accept it
                    acceptedProductions.append(rule)
                else:
                    # print("IFRULEA:",rule, len(rule))
                    assert len(rule[1])==2
                    assert rule[1][0][0]==None
                    assert rule[1][1][0]==None
                    if rule[1][0][1]==rule[1][1][1]:
                        # Same non-terminal
                        # -> Update the lambda
                        # print("IFRULE:",rule, len(rule))
                        if len(rule)==2:
                            newRule = (rule[0],rule[1], lambda x: utils.total_set_order(x[0],x[1]))
                        else:
                            assert len(rule)==3
                            newRule = (rule[0],rule[1], lambda x,u=rule[2]: utils.total_set_order(x[0],x[1]) and u(x))
                        acceptedProductions.append(newRule)
                    else:
                        acceptedProductions.append(rule)
                  
            self.nonterminals[nonterminal] = optimized_grammar_nonterminal(self.nonterminals[nonterminal].sort,frozenset(acceptedProductions))
                            
            
    def removeUnreachableRules(self):
        """Removes all rules that are not reachable (anymore) from the Start rule"""
        reachable = set(["Start"])
        todo = list(["Start"])
        while len(todo)>0:
            thisOne = todo[0]
            todo = todo[1:]

            # Check what is reachable from this rule
            for rule in self.nonterminals[thisOne].productions:
                if rule[0]==NodeType.CONST:
                    pass
                elif rule[0]==NodeType.VAR:
                    pass
                else:
                    # Operator application
                    for a in rule[1]:
                        assert len(a)==2
                        if not a[1] in reachable:
                            reachable.add(a[1])
                            todo.append(a[1])

        # Delete what is not reachable.
        deadRules = set(self.nonterminals.keys()).difference(reachable)
        for rule in deadRules:
            self.nonterminals.pop(rule)


    def performAllOptimizations(self):
        """This function is to be called from the user of the grammar in order to perform all the
           optimizations that are sane for the purpose of SyGuS synthesis"""
        # print("Grammar opt 1:",self)
        self.removeSingleNonterminalRighthandRules()
        # print("Grammar opt 2:",self)
        self.removeDuplicateNonterminals()
        # print("Grammar opt 3:",self)
        self.makeAssociativeOperatorsAndSomeOthersRightHeavy()
        # print("Grammar opt 4:",self)
        self.removeReferencesToSuperfluousConstants()
        self.removeUnreachableRules()
        # print("Grammar opt 5:",self)
        self.removeRedundantConstantConstruction()
        self.removeUnreachableRules()
        # print("Grammar opt 7:",self)
        self.removeReferencesToOperationNullifyingConstants()
        self.removeUnreachableRules()
        # print("Grammar opt 8:",self)
        self.removeDoubleNegation()
        self.removeUnreachableRules()
        # print("Grammar opt 9:",self)
        self.addUpperAndLowerBoundsForSupports()
        # print("Grammar opt 10:",self)
        self.enforceSupportOrderedNessOnBinaryAssociativeOperations()
        # print("Grammar opt 11:",self)




        # FOR FILTERING:
        # - TODO: No self-AND/ORing,
        # - TODO: No superfluous multi-operation constant building if we already have the constants...
        # - TODO: Lexicographical minimality for equality and also if we have (LE/GE) at the same time in the grammar for the same rule)
        
        # FOR GRAMMAR:
        # For rules of the form Term-> A OR A, the support should be ordered...

        # TODO: 
        # TODO: Minimal version of DeMorgan: No AND(NOT(..),NOT(..)) of we have NOT(OR()) as well... 
        # TODO: We need to cache all calls to checkRealizable (example polynom.sl), as
        #       there may be multiple grammar rules that allow to compute the same results, but
        #       that are not detected to be superflous by these rules

    def findArgument(self,name):
        for a in self.args:
            if a["name"] == name:
                return a
        raise Exception("Error: Did not find argument "+name+" in grammar.")


       


# ==================================================
# Some tests
# ==================================================
if __name__ == "__main__":
    print("Performing some tests of grammar.py...")

    class example_grammar:
        def __init__(self):
            self.name = "f"
            self.sort = ExpressionSort.fromString("BitVec:32")
            self.args = [{"name":"x","sort":ExpressionSort.fromString("BitVec:32")}]
            self.nonterminals = [{"name":"Start","sort":ExpressionSort.fromString("BitVec:32"),"productions":[(NodeType.BVAND, [(None, 'Start'), (None, 'Start')]), (NodeType.BVADD, [(NodeType.BVMUL, [(None, 'Start'), (None, 'Start')]), (None, 'Start')]), (NodeType.BVAND, [(NodeType.BVMUL, [(None, 'Start'), (None, 'Start')]), (None, 'Start')]), (NodeType.BVADD, [(None, 'Start'), (None, 'Start')]), (NodeType.VAR, 'x', ExpressionSort.fromString("BitVec:32")), (NodeType.CONST, '1', ExpressionSort.fromString("BitVec:32"))]}]

    modifiedGrammar = optimized_grammar(example_grammar())
    modifiedGrammar.performAllOptimizations()
    print("\n\nModified grammar:\n",modifiedGrammar)
