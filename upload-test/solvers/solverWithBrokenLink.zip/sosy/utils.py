#!/usr/bin/python3.4
# Stuffed Software Synthesis (SOSY)
# Copyright (C) 2009-2015  University of Bremen
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#
# @file utils.py
#
# @authors Ruediger Ehlers
#          Heinz Riener
#
# @version 1.0
#
import re, itertools, copy

curr_id = 0
def id():
    """Returns a running id number"""
    global curr_id
    curr_id = curr_id + 1
    return curr_id

def binary(num, pre='0b', length=8, spacer=0):
    return '{0}{{:{1}>{2}}}'.format(pre, spacer, length).format(bin(num)[2:])

# Slightly modified from http://stackoverflow.com/questions/16259923/how-can-i-escape-latex-special-characters-inside-django-templates
def tex_escape(text):
    """
        :param text: a plain text message
        :return: the message escaped to appear correctly in LaTeX
    """
    conv = {
        '&': r'\&',
        '%': r'\%',
        '$': r'\$',
        '#': r'\#',
        '_': r'\_',
        '{': r'\{',
        '}': r'\}',
        '~': r'\textasciitilde{}',
        '^': r'\^{}',
        '\\': r'\textbackslash{}',
        '<': r'\textless{}',
        '>': r'\textgreater{}',
    }
    regex = re.compile('|'.join(re.escape(key) for key in sorted(conv.keys(), key = lambda item: - len(item))))
    return regex.sub(lambda match: conv[match.group()], text)



def powerset(iterable):
    """A receipe from the itertools documentation"""
    s = list(iterable)
    return itertools.chain.from_iterable(itertools.combinations(s, r) for r in range(len(s)+1))


def total_set_order(u,v):
    """Implements a total order between sets. u <order> v is true if u is the 'lighter' set of the two. """
    total = list(u.union(v))
    total.sort()
    # print ("TotalSetOrder:",u,v)
    for a in total:
        if not a in u:
            # print ("TotalSetOrder: True")
            return True
        if not a in v:
            # print ("TotalSetOrder: False")
            return False
    return len(u)<=len(v)


def computeNSubsetTuplesWhoseUnionIsTheParameter(myset,nofsubsets):
    """ Used for distributing a support set among a set of parameters """
    assert isinstance( nofsubsets, int )
    assert nofsubsets>0
    if nofsubsets==1:
        yield [frozenset(myset)]
        return
    for subset in powerset(myset):
        for toremove in powerset(subset):
            rest = frozenset(myset).difference(toremove)
            lu = computeNSubsetTuplesWhoseUnionIsTheParameter(rest,nofsubsets-1)
            for a in lu:
                yield [frozenset(subset)]+a
    
class NullFileObject:
    def write(self,*arg):
        pass
    def flush(self):
        pass
    def close(self):
        pass


def breaklines(string,width):
    result = ""
    while len(string)>0:
        if len(result)>0:
            result = result + "\n" 
        result = result + string[0:72]
        string = string[72:]
    return result


def debug_breakpoint():
    """
    From: http://stackoverflow.com/questions/19754458/open-interactive-python-console-from-a-script
    Python debug breakpoint.
    """
    from code import InteractiveConsole
    from inspect import currentframe
    try:
        import readline # noqa
    except ImportError:
        pass

    caller = currentframe().f_back

    env = {}
    env.update(caller.f_globals)
    env.update(caller.f_locals)

    shell = InteractiveConsole(env)
    shell.interact(
        '* Break: {} ::: Line {}\n'
        '* Continue with Ctrl+D...'.format(
            caller.f_code.co_filename, caller.f_lineno
        )
    )

# Smart iterator for dicts - Used for grammar objects
def iterator_for_keyset_in_dict_that_works_on_dicts_on_which_elements_are_continuously_added(inputDict):
    done = set([])
    while len(done)!=len(inputDict):
        newOnes = set(inputDict.keys())
        for a in newOnes:
            if not a in done:
                done.add(a)
                yield a
    return    


# ==========================
# Tests
# ==========================
if __name__ == "__main__":

    A = {1:2,2:4,3:5}
    for u in iterator_for_keyset_in_dict_that_works_on_dicts_on_which_elements_are_continuously_added(A):
        print(u,"->",A[u])
        if u+3<=10:
            A[u+3] = A[u]+4
    
    # res = computeNSubsetTuplesWhoseUnionIsTheParameter([1,2,3,4,5],3)
    # for a in res:
    #     print("- Sln:")
    #     for b in a:
    #         print("  -> "+str(b))


