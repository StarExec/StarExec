/**
 * Outputs the version of GCC that was used to build this solver
 * followed by "SAT"
 */

#include <stdio.h>  // printf
#include <stdlib.h> // EXIT_SUCCESS

int main(void) {
	printf("GCC %d.%d.%d\n", __GNUC__, __GNUC_MINOR__, __GNUC_PATCHLEVEL__);
	puts("sat");
	return EXIT_SUCCESS;
}
