#include <stdio.h>

void main(void) {
    puts("sat\n");
    return;
}
