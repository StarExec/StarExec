#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
  long num = atol(argv[1]) / sizeof(int);
  int *arr = (int *)malloc(sizeof(int) * num);
  long cur = 0;

  while(1) {
    arr[cur] = 2 * arr[cur] + 1;
    cur = (cur + 1) % num;
  }
}
